// Reconstructed from preload.protected.jsc without executing it.
// Obfuscation removed; local variable names reconstructed. Do not execute this sample.

const crypto = require('crypto');
const stringKey = Buffer.from('7ed0532801459ae4d4ecdb2abcc00771bf9e8b35d16155970d500e44ff9aae3f', 'hex');
const decryptedStrings = new Map();
global.__decrypt = function decryptString(encrypted) {
  if (decryptedStrings.has(encrypted)) return decryptedStrings.get(encrypted);
  const [iv, ciphertext] = encrypted.split(':');
  const decipher = crypto.createDecipheriv('aes-256-cbc', stringKey, Buffer.from(iv, 'hex'));
  const plaintext = decipher.update(ciphertext, 'hex', 'utf8') + decipher.final('utf8');
  decryptedStrings.set(encrypted, plaintext);
  return plaintext;
};
Object.defineProperty(exports, '__esModule', { value: true });

const { contextBridge, ipcRenderer, desktopCapturer } = require('electron');

const electronAPI = {
  loadTheme(theme) {
    ipcRenderer.send('load-theme', theme);
  },
  onThemeLoaded(callback) {
    ipcRenderer.on('theme-loaded', (_event, data) => callback(data));
  },
  async getAvailableThemes() {
    return ipcRenderer.invoke('get-available-themes');
  },
  async getConfig() {
    return ipcRenderer.invoke('get-config');
  },
  onLoadTheme(callback) {
    ipcRenderer.on('load-theme', (_event, data) => callback(data));
  },
  minimizeToTray() {
    ipcRenderer.send('minimize-to-tray');
  },
  closeApp() {
    ipcRenderer.send('close-app');
  },
  getPlatform() {
    return process.platform;
  },
  getNodeVersion() {
    return process.versions.node;
  },
  getElectronVersion() {
    return process.versions.electron;
  },
  removeThemeListener() {
    ipcRenderer.removeAllListeners('theme-loaded');
  },
  removeLoadThemeListener() {
    ipcRenderer.removeAllListeners('load-theme');
  },
  loadHtmlPage(html) {
    ipcRenderer.send('load-html', { html });
  },
  sendChatMessage(message) {
    return ipcRenderer.send('chat-message', { message });
  },
  onChatMessage(callback) {
    ipcRenderer.on('chat-message-received', (_event, data) => {
      callback(data);
    });
  },
  removeAllListeners(channel) {
    ipcRenderer.removeAllListeners(channel);
  },
  async getScreenFrame() {
    try {
      const sources = await desktopCapturer.getSources({
        types: ['screen'],
        thumbnailSize: { width: 1280, height: 720 }
      });
      if (sources && sources.length > 0) {
        return sources[0].thumbnail.toDataURL();
      }
      return null;
    } catch (_error) {
      return null;
    }
  },
  hideWindow() {
    ipcRenderer.send('hide-window');
  },
  showWarningDialog() {
    ipcRenderer.send('show-warning-dialog');
  }
};

contextBridge.exposeInMainWorld('electronAPI', electronAPI);
