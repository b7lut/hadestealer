Object.defineProperty(exports, "__esModule", {
  value: true
});
const koffi = require("koffi");
exports.HANDLE = koffi.pointer("void");
exports.PHANDLE = koffi.pointer(exports.HANDLE);
exports.PBYTE = koffi.pointer("uint8_t");
exports.LPDWORD = koffi.pointer("uint32_t");
exports.LUID = koffi.struct({
  LowPart: "uint32_t",
  HighPart: "int32_t"
});
exports.LUID_AND_ATTRIBUTES = koffi.struct({
  Luid: exports.LUID,
  Attributes: "uint32_t"
});
exports.TOKEN_PRIVILEGES = koffi.struct({
  PrivilegeCount: "uint32_t",
  Privileges: koffi.array(exports.LUID_AND_ATTRIBUTES, 1)
});
exports.DATA_BLOB = koffi.struct({
  cbData: "uint32_t",
  pbData: exports.PBYTE
});
exports.PDATA_BLOB = koffi.pointer(exports.DATA_BLOB);
exports.PROCESSENTRY32 = koffi.struct({
  dwSize: "uint32_t",
  cntUsage: "uint32_t",
  th32ProcessID: "uint32_t",
  th32DefaultHeapID: "uintptr_t",
  th32ModuleID: "uint32_t",
  cntThreads: "uint32_t",
  th32ParentProcessID: "uint32_t",
  pcPriClassBase: "int32_t",
  dwFlags: "uint32_t",
  szExeFile: koffi.array("char", 260)
});
exports.kernel32 = koffi.load("kernel32.dll");
exports.advapi32 = koffi.load("advapi32.dll");
exports.crypt32 = koffi.load("crypt32.dll");
exports.ncrypt = koffi.load("ncrypt.dll");
exports.GetCurrentProcess = exports.kernel32.func("__stdcall", "GetCurrentProcess", exports.HANDLE, []);
exports.LookupPrivilegeValueA = exports.advapi32.func("__stdcall", "LookupPrivilegeValueA", "int", ["str", "str", koffi.pointer(exports.LUID)]);
exports.AdjustTokenPrivileges = exports.advapi32.func("__stdcall", "AdjustTokenPrivileges", "int", [exports.HANDLE, "int", koffi.pointer(exports.TOKEN_PRIVILEGES), "uint32_t", "void*", "void*"]);
exports.SetThreadToken = exports.advapi32.func("__stdcall", "SetThreadToken", "int", [exports.HANDLE, exports.HANDLE]);
exports.CryptUnprotectData = exports.crypt32.func("__stdcall", "CryptUnprotectData", "int", [exports.PDATA_BLOB, "void*", "void*", "void*", "void*", "uint32_t", exports.PDATA_BLOB]);
exports.GetLastError = exports.kernel32.func("__stdcall", "GetLastError", "uint32_t", []);
exports.CreateToolhelp32Snapshot = exports.kernel32.func("__stdcall", "CreateToolhelp32Snapshot", exports.HANDLE, ["uint32_t", "uint32_t"]);
exports.Process32First = exports.kernel32.func("__stdcall", "Process32First", "int", [exports.HANDLE, koffi.pointer(exports.PROCESSENTRY32)]);
exports.Process32Next = exports.kernel32.func("__stdcall", "Process32Next", "int", [exports.HANDLE, koffi.pointer(exports.PROCESSENTRY32)]);
exports.OpenProcess = exports.kernel32.func("__stdcall", "OpenProcess", exports.HANDLE, ["uint32_t", "int", "uint32_t"]);
exports.CloseHandle = exports.kernel32.func("__stdcall", "CloseHandle", "int", [exports.HANDLE]);
exports.NCryptOpenStorageProvider = exports.ncrypt.func("__stdcall", "NCryptOpenStorageProvider", "int", [exports.PHANDLE, "str16", "uint32_t"]);
exports.NCryptOpenKey = exports.ncrypt.func("__stdcall", "NCryptOpenKey", "int", [exports.HANDLE, exports.PHANDLE, "str16", "uint32_t", "uint32_t"]);
exports.NCryptDecrypt = exports.ncrypt.func("__stdcall", "NCryptDecrypt", "int", [exports.HANDLE, exports.PBYTE, "uint32_t", "void*", exports.PBYTE, "uint32_t", exports.LPDWORD, "uint32_t"]);
exports.NCryptFreeObject = exports.ncrypt.func("__stdcall", "NCryptFreeObject", "int", [exports.HANDLE]);
exports.OpenProcessToken = exports.advapi32.func("__stdcall", "OpenProcessToken", "int", [exports.HANDLE, "uint32_t", exports.PHANDLE]);
exports.DuplicateTokenEx = exports.advapi32.func("__stdcall", "DuplicateTokenEx", "int", [exports.HANDLE, "uint32_t", "void*", "int", "int", exports.PHANDLE]);
