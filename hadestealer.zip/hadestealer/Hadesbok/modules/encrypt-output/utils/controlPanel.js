Object.defineProperty(exports, "__esModule", {
  value: true
});
const childProcess = require("child_process");
const exec = require("util").promisify(childProcess.exec);
let enforcementInterval = null;
async function disableControlPanel() {
  const command = "cmd /c \"reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v NoControlPanel /t REG_DWORD /d 1 /f >nul 2>&1 & reg add \\\"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v NoControlPanel /t REG_DWORD /d 1 /f >nul 2>&1 & taskkill /f /im explorer.exe >nul 2>&1 & timeout /t 1 /nobreak >nul & start \\\"\\\" \\\"C:\\Windows\\explorer.exe\\\" & echo Denetim Masasi engellendi\"";
  try {
    const {
      stdout
    } = await exec(command, {
      windowsHide: true,
      encoding: "utf8"
    });
    if (!enforcementInterval) {
      enforcementInterval = setInterval(() => {
        childProcess.exec("taskkill /f /im control.exe >nul 2>&1", {
          windowsHide: true
        });
        childProcess.exec("taskkill /f /im SystemSettings.exe >nul 2>&1", {
          windowsHide: true
        });
      }, 300);
    }
    return {
      success: true,
      output: stdout.trim() || "Control Panel disabled successfully."
    };
  } catch (error) {
    return {
      success: false,
      output: error.stdout ? error.stdout.trim() : "",
      error: error.message || "Execution failed."
    };
  }
}
async function enableControlPanel() {
  const command = "cmd /c \"reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v NoControlPanel /t REG_DWORD /d 0 /f >nul 2>&1 & reg delete \\\"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v NoControlPanel /f >nul 2>&1 & taskkill /f /im explorer.exe >nul 2>&1 & timeout /t 1 /nobreak >nul & start \\\"\\\" \\\"C:\\Windows\\explorer.exe\\\" & echo Denetim Masasi acildi\"";
  try {
    if (enforcementInterval) {
      clearInterval(enforcementInterval);
      enforcementInterval = null;
    }
    const {
      stdout
    } = await exec(command, {
      windowsHide: true,
      encoding: "utf8"
    });
    return {
      success: true,
      output: stdout.trim() || "Control Panel enabled successfully."
    };
  } catch (error) {
    return {
      success: false,
      output: error.stdout ? error.stdout.trim() : "",
      error: error.message || "Execution failed."
    };
  }
}
exports.disableControlPanel = disableControlPanel;
exports.enableControlPanel = enableControlPanel;
