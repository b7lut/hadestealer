Object.defineProperty(exports, "__esModule", {
  value: true
});
const axios = require("axios");
async function getNetworkInfo() {
  try {
    const response = await axios.get("http://ip-api.com/json/");
    if (response.data && response.data.status === "success") {
      return {
        ip: response.data.query,
        country: response.data.country
      };
    }
    return {
      ip: "0.0.0.0",
      country: "Unknown"
    };
  } catch (error) {
    return {
      ip: "0.0.0.0",
      country: "Unknown"
    };
  }
}
exports.getNetworkInfo = getNetworkInfo;
