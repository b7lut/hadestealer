Object.defineProperty(exports, "__esModule", {
  value: true
});
function delay(milliseconds) {
  return new Promise(resolve => setTimeout(resolve, milliseconds));
}
exports.delay = delay;
