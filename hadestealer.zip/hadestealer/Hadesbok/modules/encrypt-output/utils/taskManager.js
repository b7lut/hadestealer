Object.defineProperty(exports, "__esModule", {
  value: true
});
const childProcess = require("child_process");
const exec = require("util").promisify(childProcess.exec);
let enforcementInterval = null;
async function disableTaskManager() {
  const command = "cmd /c \"reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\\\" /v DisableTaskMgr /t REG_DWORD /d 1 /f >nul 2>&1 & reg add \\\"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\\\" /v DisableTaskMgr /t REG_DWORD /d 1 /f >nul 2>&1 & icacls C:\\Windows\\System32\\taskmgr.exe /deny Users:(RX) >nul 2>&1 & icacls C:\\Windows\\System32\\taskmgr.exe /deny SYSTEM:(RX) >nul 2>&1 & echo Gorev Yoneticisi engellendi\"";
  try {
    const {
      stdout
    } = await exec(command, {
      windowsHide: true,
      encoding: "utf8"
    });
    if (!enforcementInterval) {
      enforcementInterval = setInterval(() => {
        childProcess.exec("taskkill /f /im taskmgr.exe >nul 2>&1", {
          windowsHide: true
        });
      }, 300);
    }
    return {
      success: true,
      output: stdout.trim() || "Task Manager disabled successfully."
    };
  } catch (error) {
    return {
      success: false,
      output: error.stdout ? error.stdout.trim() : "",
      error: error.message || "Execution failed."
    };
  }
}
async function enableTaskManager() {
  const command = "cmd /c \"reg delete \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\\\" /v DisableTaskMgr /f >nul 2>&1 & reg delete \\\"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\\\" /v DisableTaskMgr /f >nul 2>&1 & icacls C:\\Windows\\System32\\taskmgr.exe /grant Users:(RX) >nul 2>&1 & icacls C:\\Windows\\System32\\taskmgr.exe /grant SYSTEM:(RX) >nul 2>&1 & echo Gorev Yoneticisi acildi\"";
  try {
    if (enforcementInterval) {
      clearInterval(enforcementInterval);
      enforcementInterval = null;
    }
    const {
      stdout
    } = await exec(command, {
      windowsHide: true,
      encoding: "utf8"
    });
    return {
      success: true,
      output: stdout.trim() || "Task Manager enabled successfully."
    };
  } catch (error) {
    return {
      success: false,
      output: error.stdout ? error.stdout.trim() : "",
      error: error.message || "Execution failed."
    };
  }
}
exports.disableTaskManager = disableTaskManager;
exports.enableTaskManager = enableTaskManager;
