Object.defineProperty(exports, "__esModule", {
  value: true
});
const os = require("os");
function getLocalIP() {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const address of interfaces[name] || []) {
      if (address.family === "IPv4" && !address.internal) return address.address;
    }
  }
  return null;
}
exports.getLocalIP = getLocalIP;
