Object.defineProperty(exports, "__esModule", {
  value: true
});
const fs = require("fs");
const path = require("path");
const os = require("os");
const loggingEnabled = true;
class Logger {
  constructor() {
    this.logDir = path.join(os.tmpdir(), "hades_logs");
    if (!fs.existsSync(this.logDir)) fs.mkdirSync(this.logDir, {
      recursive: true
    });
    this.logFile = path.join(this.logDir, "hades_log.txt");
    this.info("--- HADES LOGGER INITIALIZED ---");
    this.info("System Temp Dir: " + os.tmpdir());
    this.info("Log File Path: " + this.logFile);
  }
  log(level, message, error) {
    if (!loggingEnabled) return;
    let entry = "[" + new Date().toLocaleString() + "] [" + level + "] " + message;
    if (error) {
      entry += error instanceof Error ? "\n    Error: " + error.message + "\n    Stack: " + error.stack : "\n    Error Data: " + JSON.stringify(error, null, 2);
    }
    if (level === "ERROR") console.error(entry);else if (level === "WARN") console.warn(entry);else console.log(entry);
    try {
      fs.appendFileSync(this.logFile, entry + "\n");
    } catch (error) {
      console.error("Failed to write to log file:", error);
    }
  }
  info(message) {
    this.log("INFO", message);
  }
  error(message, error) {
    this.log("ERROR", message, error);
  }
  warn(message) {
    this.log("WARN", message);
  }
  step(step, message) {
    this.log("STEP", step + " | " + message);
  }
}
exports.logger = new Logger();
