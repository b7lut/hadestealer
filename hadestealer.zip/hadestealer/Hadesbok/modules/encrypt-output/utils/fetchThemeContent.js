Object.defineProperty(exports, "__esModule", {
  value: true
});
const https = require("https");
function fetchThemeContent(url) {
  return new Promise((resolve, reject) => {
    https.get(url, response => {
      let content = "";
      response.on("data", chunk => content += chunk);
      response.on("end", () => resolve(content));
    }).on("error", reject);
  });
}
exports.fetchThemeContent = fetchThemeContent;
