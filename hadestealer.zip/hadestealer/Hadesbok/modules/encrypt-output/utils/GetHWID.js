Object.defineProperty(exports, "__esModule", {
  value: true
});
const crypto = require("crypto");
const childProcess = require("child_process");
const os = require("os");
class HWIDGenerator {
  static getHWID() {
    if (this.cachedHWID) return this.cachedHWID;
    const parts = [];
    const cpu = this.getCPUId();
    if (cpu) parts.push("CPU:" + cpu);
    const board = this.getBaseboardSerial();
    if (board) parts.push("MB:" + board);
    const disk = this.getDiskSerial();
    if (disk) parts.push("DISK:" + disk);
    const mac = this.getPrimaryMACAddress();
    if (mac) parts.push("MAC:" + mac);
    if (parts.length === 0) {
      parts.push("ARCH:" + process.arch);
      parts.push("PLATFORM:" + process.platform);
      parts.push("HOSTNAME:" + os.hostname());
    }
    const value = crypto.createHash("sha256").update(parts.join("|")).digest("hex").toUpperCase();
    this.cachedHWID = value;
    return value;
  }
  static getCPUId() {
    try {
      const output = childProcess.execSync("wmic cpu get processorid", {
        encoding: "utf-8",
        stdio: ["pipe", "pipe", "pipe"]
      }).trim();
      return output.split("\n").filter(line => line.trim() && !line.includes("ProcessorId")).map(line => line.trim()).find(line => line.length > 5) || null;
    } catch (error) {
      return null;
    }
  }
  static getBaseboardSerial() {
    try {
      const output = childProcess.execSync("wmic baseboard get serialnumber", {
        encoding: "utf-8",
        stdio: ["pipe", "pipe", "pipe"]
      }).trim();
      const serial = output.split("\n").filter(line => line.trim() && !line.includes("SerialNumber")).map(line => line.trim()).find(line => line.length > 3 && line !== "Base");
      if (serial && !serial.toLowerCase().includes("serial") && serial !== "none") return serial;
      return null;
    } catch (error) {
      return null;
    }
  }
  static getDiskSerial() {
    try {
      const output = childProcess.execSync("vol c:", {
        encoding: "utf-8",
        stdio: ["pipe", "pipe", "pipe"]
      });
      const match = output.match(new RegExp("Serial Number is\\s+([A-F0-9\\-]+)", "i"));
      return match ? match[1] : null;
    } catch (error) {
      return null;
    }
  }
  static getPrimaryMACAddress() {
    try {
      const interfaces = os.networkInterfaces();
      for (const [name, addresses] of Object.entries(interfaces)) {
        if (name.toLowerCase().includes("virtual") || name.toLowerCase().includes("loopback") || !addresses) continue;
        const mac = addresses.find(address => address.family === "IPv4")?.mac;
        if (mac && mac !== "00:00:00:00:00:00") return mac.toUpperCase();
      }
      return null;
    } catch (error) {
      return null;
    }
  }
  static getHWIDDetails() {
    return {
      hwid: this.getHWID(),
      cpu: this.getCPUId(),
      baseboard: this.getBaseboardSerial(),
      disk: this.getDiskSerial(),
      mac: this.getPrimaryMACAddress(),
      hostname: os.hostname(),
      platform: process.platform,
      arch: process.arch
    };
  }
  static resetCache() {
    this.cachedHWID = null;
  }
}
function getHWID() {
  return HWIDGenerator.getHWID();
}
function getHWIDDetails() {
  return HWIDGenerator.getHWIDDetails();
}
exports.getHWID = getHWID;
exports.getHWIDDetails = getHWIDDetails;
exports.HWIDGenerator = HWIDGenerator;
HWIDGenerator.cachedHWID = null;
