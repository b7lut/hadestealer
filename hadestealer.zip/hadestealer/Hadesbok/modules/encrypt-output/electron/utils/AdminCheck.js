Object.defineProperty(exports, "__esModule", {
  value: true
});
const childProcess = require("child_process");
const {
  app
} = require("electron");
const exec = require("util").promisify(childProcess.exec);
class AdminCheck {
  static async checkAdminPrivileges() {
    try {
      if (process.platform !== "win32") return true;
      await exec("net session", {
        windowsHide: true
      });
      return true;
    } catch (error) {
      return false;
    }
  }
  static requestAdminPrivileges() {
    try {
      const executable = app.getPath("exe");
      if (process.platform === "win32") {
        const command = "powershell.exe -Command \"Start-Process '" + executable + "' -Verb RunAs\"";
        childProcess.exec(command, {
          windowsHide: true
        }, error => {
          if (error) console.error("Failed to elevate privileges:", error);
        });
      }
    } catch (error) {
      console.error("Error requesting admin privileges:", error);
    }
  }
  static async executeAsAdmin(command) {
    try {
      if (!(await this.checkAdminPrivileges())) throw new Error("Not running with admin privileges");
      const {
        stdout,
        stderr
      } = await exec(command, {
        shell: "powershell.exe",
        windowsHide: true
      });
      return {
        stdout,
        stderr
      };
    } catch (error) {
      return {
        stdout: "",
        stderr: error.message || "Command execution failed"
      };
    }
  }
  static async writeToRegistry(key, name, value) {
    try {
      if (!(await this.checkAdminPrivileges())) return false;
      const result = await this.executeAsAdmin("reg add \"" + key + "\" /v " + name + " /d \"" + value + "\" /f");
      return !result.stderr;
    } catch (error) {
      return false;
    }
  }
  static async setupAutorun(name, executable) {
    try {
      return await this.writeToRegistry("HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run", name, executable);
    } catch (error) {
      return false;
    }
  }
  static async removeAutorun(name) {
    try {
      if (!(await this.checkAdminPrivileges())) return false;
      const result = await this.executeAsAdmin("reg delete \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run\" /v " + name + " /f");
      return !result.stderr;
    } catch (error) {
      return false;
    }
  }
  static async addFirewallRule(name, executable, action = "allow") {
    try {
      if (!(await this.checkAdminPrivileges())) return false;
      const command = "netsh advfirewall firewall add rule name=\"" + name + "\" dir=out action=" + action + " program=\"" + executable + "\" enable=yes";
      const result = await this.executeAsAdmin(command);
      return !result.stderr;
    } catch (error) {
      return false;
    }
  }
}
exports.AdminCheck = AdminCheck;
