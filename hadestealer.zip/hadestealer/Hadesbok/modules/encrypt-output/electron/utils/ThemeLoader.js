Object.defineProperty(exports, "__esModule", {
  value: true
});
const path = require("path");
const fs = require("fs");
const {
  app
} = require("electron");
class ThemeLoader {
  constructor() {
    this.themesDir = process.env.NODE_ENV === "development" ? path.join(__dirname, "../../assets/themes") : path.join(app.getAppPath(), "assets/themes");
  }
  getAvailableThemes() {
    try {
      if (!fs.existsSync(this.themesDir)) return [];
      return fs.readdirSync(this.themesDir).filter(name => name.endsWith(".html")).map(name => path.basename(name, ".html"));
    } catch (error) {
      return [];
    }
  }
  getThemePath(name) {
    if (name.includes("..") || name.includes("/") || name.includes("\\")) throw new Error("Invalid theme name");
    return path.join(this.themesDir, name + ".html");
  }
  async getThemeContent(name) {
    try {
      const filename = this.getThemePath(name);
      if (!fs.existsSync(filename)) throw new Error("Theme file not found: " + name);
      return fs.readFileSync(filename, "utf-8");
    } catch (error) {
      throw error;
    }
  }
  async loadThemeContent(name) {
    try {
      return {
        html: await this.getThemeContent(name),
        success: true
      };
    } catch (error) {
      return {
        html: "",
        success: false,
        error: error.message
      };
    }
  }
  isThemeExists(name) {
    try {
      return fs.existsSync(this.getThemePath(name));
    } catch (error) {
      return false;
    }
  }
  getThemeInfo(name) {
    const filename = this.getThemePath(name);
    const exists = this.isThemeExists(name);
    return {
      name,
      path: filename,
      size: exists ? fs.statSync(filename).size : 0,
      exists
    };
  }
  getAllThemesInfo() {
    return this.getAvailableThemes().map(name => this.getThemeInfo(name));
  }
  async loadCustomTheme(html) {
    try {
      if (!html || html.trim().length === 0) throw new Error("HTML content is empty");
      if (!html.toLowerCase().includes("<html")) throw new Error("Invalid HTML content");
      return {
        success: true
      };
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  }
}
exports.ThemeLoader = ThemeLoader;
